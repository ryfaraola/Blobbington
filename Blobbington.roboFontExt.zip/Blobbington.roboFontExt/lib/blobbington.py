from mojo.events import BaseEventTool, installTool
from mojo.extensions import getExtensionDefault, setExtensionDefault
import math
import AppKit
from booleanOperations.booleanGlyph import BooleanGlyph
from mojo.roboFont import CurrentGlyph, RGlyph
from vanilla import FloatingWindow, Slider, TextBox, EditText, EditText

DEFAULT_SIZE = 60
DEFAULT_ANGLE = 0
DEFAULT_ROUNDNESS = 100
DEFAULT_FIDELITY = 5

K = 0.5522847498
PREFS = "com.commodityfoundry.blobbington"

_sharedPanel = None

def loadSetting(name, fallback):
    return getExtensionDefault(f"{PREFS}.{name}", fallback)

def saveSetting(name, value):
    setExtensionDefault(f"{PREFS}.{name}", value)

def perpendicular(ax, ay, bx, by):
    dx = bx - ax
    dy = by - ay
    length = math.hypot(dx, dy)
    if length == 0:
        return (0, 1)
    return (-dy / length, dx / length)

def strokeDirection(ax, ay, bx, by):
    dx = bx - ax
    dy = by - ay
    length = math.hypot(dx, dy)
    if length == 0:
        return (1, 0)
    return (dx / length, dy / length)

MIN_POINT_DISTANCE = 4.0
CORNER_ANGLE = 40.0
CORNER_WINDOW = 3
SMOOTH_PASSES = 2

def turnAngle(p0, p1, p2):
    ax, ay = p1[0] - p0[0], p1[1] - p0[1]
    bx, by = p2[0] - p1[0], p2[1] - p1[1]
    m1 = math.hypot(ax, ay)
    m2 = math.hypot(bx, by)
    if m1 == 0 or m2 == 0:
        return 0.0
    dot = (ax * bx + ay * by) / (m1 * m2)
    dot = max(-1.0, min(1.0, dot))
    return math.degrees(math.acos(dot))

def cullByDistance(points):
    culled = [points[0]]
    for pt in points[1:-1]:
        lx, ly = culled[-1]
        if math.hypot(pt[0] - lx, pt[1] - ly) >= MIN_POINT_DISTANCE:
            culled.append(pt)
    culled.append(points[-1])
    return culled

def findCorners(pts):
    corners = set()
    n = len(pts)
    w = CORNER_WINDOW
    for i in range(1, n - 1):
        a = pts[max(0, i - w)]
        b = pts[i]
        c = pts[min(n - 1, i + w)]
        if turnAngle(a, b, c) >= CORNER_ANGLE:
            corners.add(i)
    return corners

def smoothCenterline(pts, corners):
    if len(pts) < 3:
        return pts
    out = list(pts)
    for _ in range(SMOOTH_PASSES):
        nxt = [out[0]]
        for i in range(1, len(out) - 1):
            if i in corners:
                nxt.append(out[i])
                continue
            px, py = out[i - 1]
            cx, cy = out[i]
            qx, qy = out[i + 1]
            nxt.append(((px + 2 * cx + qx) / 4.0, (py + 2 * cy + qy) / 4.0))
        nxt.append(out[-1])
        out = nxt
    return out

def subsample(points, fidelity):
    if len(points) < 3:
        return points

    culled = cullByDistance(points)
    if len(culled) < 3:
        return culled

    corners = findCorners(culled)
    culled = smoothCenterline(culled, corners)

    every = int(fidelity) + 1
    kept = [culled[0]]
    since = 0
    for i in range(1, len(culled) - 1):
        since += 1
        if i in corners:
            if i - 1 not in corners and culled[i - 1] != kept[-1]:
                kept.append(culled[i - 1])
            kept.append(culled[i])
            if i + 1 < len(culled) - 1 and i + 1 not in corners:
                kept.append(culled[i + 1])
            since = 0
        elif since >= every:
            kept.append(culled[i])
            since = 0
    kept.append(culled[-1])

    deduped = [kept[0]]
    for pt in kept[1:]:
        if pt != deduped[-1]:
            deduped.append(pt)
    return deduped

def ovalTransform(rx, ry, angle_deg):
    angle = math.radians(angle_deg)
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    def M(px, py):
        sx = rx * px
        sy = ry * py
        return (sx * cos_a - sy * sin_a, sx * sin_a + sy * cos_a)
    return M

def ovalTransformT(rx, ry, angle_deg):
    angle = math.radians(angle_deg)
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    def MT(px, py):
        rxp = px * cos_a + py * sin_a
        ryp = -px * sin_a + py * cos_a
        return (rx * rxp, ry * ryp)
    return MT

def supportUnit(MT, nx, ny):
    tx, ty = MT(nx, ny)
    mag = math.hypot(tx, ty)
    if mag == 0:
        return (nx, ny)
    return (tx / mag, ty / mag)

def capDirection(ax, ay, outx, outy, M):
    dx, dy = -ay, ax
    wx, wy = M(dx, dy)
    if wx * outx + wy * outy < 0:
        dx, dy = ay, -ax
    return (dx, dy)

def expandStroke(centerline, rx, ry, angle_deg):
    if len(centerline) < 2:
        return None
    M = ovalTransform(rx, ry, angle_deg)
    MT = ovalTransformT(rx, ry, angle_deg)

    left = []
    right = []
    n = len(centerline)
    for i in range(n):
        if i == 0:
            nx, ny = perpendicular(centerline[0][0], centerline[0][1], centerline[1][0], centerline[1][1])
        elif i == n - 1:
            nx, ny = perpendicular(centerline[-2][0], centerline[-2][1], centerline[-1][0], centerline[-1][1])
        else:
            nx1, ny1 = perpendicular(centerline[i-1][0], centerline[i-1][1], centerline[i][0], centerline[i][1])
            nx2, ny2 = perpendicular(centerline[i][0], centerline[i][1], centerline[i+1][0], centerline[i+1][1])
            nx = (nx1 + nx2) / 2
            ny = (ny1 + ny2) / 2
            mag = math.hypot(nx, ny)
            if mag > 0:
                nx /= mag
                ny /= mag
        ux, uy = supportUnit(MT, nx, ny)
        ox, oy = M(ux, uy)
        cx, cy = centerline[i]
        left.append((cx + ox, cy + oy))
        right.append((cx - ox, cy - oy))
    return left, right

def strokeGeometry(cl, rx, ry, angle_deg):
    if len(cl) < 2:
        return None
    result = expandStroke(cl, rx, ry, angle_deg)
    if result is None:
        return None
    left, right = result
    M = ovalTransform(rx, ry, angle_deg)
    MT = ovalTransformT(rx, ry, angle_deg)

    n0x, n0y = perpendicular(cl[0][0], cl[0][1], cl[1][0], cl[1][1])
    d0x, d0y = strokeDirection(cl[1][0], cl[1][1], cl[0][0], cl[0][1])
    u0x, u0y = supportUnit(MT, n0x, n0y)
    a0 = (u0x, u0y)
    cd0 = capDirection(u0x, u0y, d0x, d0y, M)

    n1x, n1y = perpendicular(cl[-2][0], cl[-2][1], cl[-1][0], cl[-1][1])
    d1x, d1y = strokeDirection(cl[-2][0], cl[-2][1], cl[-1][0], cl[-1][1])
    u1x, u1y = supportUnit(MT, n1x, n1y)
    a1 = (-u1x, -u1y)
    cd1 = capDirection(-u1x, -u1y, d1x, d1y, M)

    return left, right, a0, cd0, a1, cd1

def capSegments(cx, cy, a, d, rx, ry, angle_deg):
    M = ovalTransform(rx, ry, angle_deg)
    ax, ay = a
    dx, dy = d

    def W(px, py):
        ox, oy = M(px, py)
        return (cx + ox, cy + oy)

    seg1 = (W(ax + K * dx, ay + K * dy),
            W(dx + K * ax, dy + K * ay),
            W(dx, dy))
    seg2 = (W(dx - K * ax, dy - K * ay),
            W(-ax + K * dx, -ay + K * dy),
            W(-ax, -ay))
    return [seg1, seg2]

def capPolyline(cx, cy, a, d, rx, ry, angle_deg, steps=10):
    M = ovalTransform(rx, ry, angle_deg)
    ax, ay = a
    dx, dy = d
    pts = []
    for i in range(1, steps):
        t = math.pi * i / steps
        px = math.cos(t) * ax + math.sin(t) * dx
        py = math.cos(t) * ay + math.sin(t) * dy
        ox, oy = M(px, py)
        pts.append((cx + ox, cy + oy))
    return pts

def smoothEdgeSegments(pts):
    segs = []
    n = len(pts)
    for i in range(n - 1):
        p0 = pts[i - 1] if i > 0 else pts[i]
        p1 = pts[i]
        p2 = pts[i + 1]
        p3 = pts[i + 2] if i + 2 < n else pts[i + 1]
        cp1 = (p1[0] + (p2[0] - p0[0]) / 6.0, p1[1] + (p2[1] - p0[1]) / 6.0)
        cp2 = (p2[0] - (p3[0] - p1[0]) / 6.0, p2[1] - (p3[1] - p1[1]) / 6.0)
        segs.append((cp1, cp2, p2))
    return segs

def markSmoothPoints(contour, tol_deg=25):
    pts = contour.points
    n = len(pts)
    for i, pt in enumerate(pts):
        if pt.type == "offcurve":
            continue
        prev = pts[(i - 1) % n]
        nxt = pts[(i + 1) % n]
        if prev.type != "offcurve" or nxt.type != "offcurve":
            continue
        vinx, viny = pt.x - prev.x, pt.y - prev.y
        voutx, vouty = nxt.x - pt.x, nxt.y - pt.y
        m1 = math.hypot(vinx, viny)
        m2 = math.hypot(voutx, vouty)
        if m1 == 0 or m2 == 0:
            continue
        dot = (vinx * voutx + viny * vouty) / (m1 * m2)
        dot = max(-1.0, min(1.0, dot))
        ang = math.degrees(math.acos(dot))
        if ang < tol_deg:
            pt.smooth = True

def buildStrokeGlyph(cl, rx, ry, angle_deg):
    geo = strokeGeometry(cl, rx, ry, angle_deg)
    if geo is None:
        return None
    left, right, a0, cd0, a1, cd1 = geo

    g = RGlyph()
    pen = g.getPen()

    pen.moveTo(right[0])
    for cp1, cp2, end in smoothEdgeSegments(right):
        pen.curveTo(cp1, cp2, end)
    for cp1, cp2, end in capSegments(cl[-1][0], cl[-1][1], a1, cd1, rx, ry, angle_deg):
        pen.curveTo(cp1, cp2, end)
    for cp1, cp2, end in smoothEdgeSegments(list(reversed(left))):
        pen.curveTo(cp1, cp2, end)
    for cp1, cp2, end in capSegments(cl[0][0], cl[0][1], a0, cd0, rx, ry, angle_deg):
        pen.curveTo(cp1, cp2, end)
    pen.closePath()
    return g

def fullOvalGlyph(cx, cy, rx, ry, angle_deg):
    M = ovalTransform(rx, ry, angle_deg)

    def W(px, py):
        ox, oy = M(px, py)
        return (cx + ox, cy + oy)

    g = RGlyph()
    pen = g.getPen()
    pen.moveTo(W(1, 0))
    pen.curveTo(W(1, K), W(K, 1), W(0, 1))
    pen.curveTo(W(-K, 1), W(-1, K), W(-1, 0))
    pen.curveTo(W(-1, -K), W(-K, -1), W(0, -1))
    pen.curveTo(W(K, -1), W(1, -K), W(1, 0))
    pen.closePath()
    return g

class BlobbingtonPanel:

    def __init__(self, tool):
        self.tool = tool
        f = loadSetting("fidelity", DEFAULT_FIDELITY)
        s = loadSetting("size", DEFAULT_SIZE)
        a = loadSetting("angle", DEFAULT_ANGLE)
        r = loadSetting("roundness", DEFAULT_ROUNDNESS)

        self.w = FloatingWindow((260, 250), "Blobbington")

        self.w.fidelityLabel = TextBox((10, 10, 240, 20), "Fidelity")
        self.w.fidelitySlider = Slider(
            (10, 28, 240, 23),
            minValue=1, maxValue=20, value=f,
            tickMarkCount=5,
            callback=self.fidelityChanged
        )
        self.w.accurateLabel = TextBox((10, 52, 120, 14), "Accurate", sizeStyle="small")
        self.w.smoothLabel = TextBox((130, 52, 120, 14), "Smooth", alignment="right", sizeStyle="small")

        self.w.sizeLabel = TextBox((10, 80, 60, 20), "Size")
        self.w.sizeField = EditText(
            (195, 78, 55, 22), text=str(int(s)),
            continuous=False, callback=self.sizeTyped)
        self.w.sizeSlider = Slider(
            (10, 102, 240, 20),
            minValue=4, maxValue=400, value=s,
            callback=self.sizeChanged
        )

        self.w.angleLabel = TextBox((10, 132, 60, 20), "Angle")
        self.w.angleField = EditText(
            (195, 130, 55, 22), text=str(int(a)),
            continuous=False, callback=self.angleTyped)
        self.w.angleSlider = Slider(
            (10, 154, 240, 20),
            minValue=0, maxValue=360, value=a,
            callback=self.angleChanged
        )

        self.w.roundnessLabel = TextBox((10, 184, 90, 20), "Roundness")
        self.w.roundnessField = EditText(
            (195, 182, 55, 22), text=str(int(r)),
            continuous=False, callback=self.roundnessTyped)
        self.w.roundnessSlider = Slider(
            (10, 206, 240, 20),
            minValue=1, maxValue=100, value=r,
            callback=self.roundnessChanged
        )

        self.w.bind("close", self.windowClosed)
        self.w.open()

    def windowClosed(self, sender):
        global _sharedPanel
        _sharedPanel = None

    def syncToTool(self, tool):
        self.tool = tool
        self.w.fidelitySlider.set(tool.fidelity)
        self.w.sizeSlider.set(tool.brushSize)
        self.w.sizeField.set(str(int(tool.brushSize)))
        self.w.angleSlider.set(tool.brushAngle)
        self.w.angleField.set(str(int(tool.brushAngle)))
        self.w.roundnessSlider.set(tool.brushRoundness)
        self.w.roundnessField.set(str(int(tool.brushRoundness)))

    def readField(self, sender, lo, hi, current):
        raw = sender.get().strip().replace("%", "")
        try:
            val = int(round(float(raw)))
        except ValueError:
            sender.set(str(int(current)))
            return None
        val = max(lo, min(hi, val))
        sender.set(str(val))
        return val

    def fidelityChanged(self, sender):
        val = int(sender.get())
        self.tool.fidelity = val
        saveSetting("fidelity", val)

    def applySize(self, val):
        self.tool.brushSize = val
        saveSetting("size", val)

    def sizeChanged(self, sender):
        val = int(sender.get())
        self.applySize(val)
        self.w.sizeField.set(str(val))

    def sizeTyped(self, sender):
        val = self.readField(sender, 4, 400, self.tool.brushSize)
        if val is None:
            return
        self.applySize(val)
        self.w.sizeSlider.set(val)

    def applyAngle(self, val):
        self.tool.brushAngle = val
        saveSetting("angle", val)

    def angleChanged(self, sender):
        val = int(sender.get())
        self.applyAngle(val)
        self.w.angleField.set(str(val))

    def angleTyped(self, sender):
        val = self.readField(sender, 0, 360, self.tool.brushAngle)
        if val is None:
            return
        self.applyAngle(val)
        self.w.angleSlider.set(val)

    def applyRoundness(self, val):
        self.tool.brushRoundness = val
        saveSetting("roundness", val)

    def roundnessChanged(self, sender):
        val = int(sender.get())
        self.applyRoundness(val)
        self.w.roundnessField.set(str(val))

    def roundnessTyped(self, sender):
        val = self.readField(sender, 1, 100, self.tool.brushRoundness)
        if val is None:
            return
        self.applyRoundness(val)
        self.w.roundnessSlider.set(val)

class BlobbingtonTool(BaseEventTool):

    def setup(self):
        self.dragPath = []
        self.fidelity = loadSetting("fidelity", DEFAULT_FIDELITY)
        self.brushSize = loadSetting("size", DEFAULT_SIZE)
        self.brushAngle = loadSetting("angle", DEFAULT_ANGLE)
        self.brushRoundness = loadSetting("roundness", DEFAULT_ROUNDNESS)
        self.cursorPos = None

    def reloadSettings(self):
        self.fidelity = loadSetting("fidelity", DEFAULT_FIDELITY)
        self.brushSize = loadSetting("size", DEFAULT_SIZE)
        self.brushAngle = loadSetting("angle", DEFAULT_ANGLE)
        self.brushRoundness = loadSetting("roundness", DEFAULT_ROUNDNESS)

    def becomeActive(self):
        global _sharedPanel
        self.reloadSettings()
        if _sharedPanel is None:
            _sharedPanel = BlobbingtonPanel(self)
        else:
            _sharedPanel.syncToTool(self)
        self.panel = _sharedPanel

    def becomeInactive(self):
        global _sharedPanel
        self.dragPath = []
        self.cursorPos = None
        if _sharedPanel is not None:
            panel = _sharedPanel
            _sharedPanel = None
            try:
                panel.w.close()
            except Exception:
                pass
        self.panel = None

    def brushRadii(self):
        rx = self.brushSize / 2.0
        ry = rx * (self.brushRoundness / 100.0)
        return rx, ry

    def getToolbarIcon(self):
        from AppKit import NSImage
        import os
        here = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else None
        candidates = []
        if here:
            candidates.append(os.path.join(os.path.dirname(here), "resources", "icon.pdf"))
        candidates.append(os.path.expanduser(
            "~/Library/Application Support/RoboFont/plugins/Blobbington.roboFontExt/resources/icon.pdf"))
        for p in candidates:
            if p and os.path.exists(p):
                img = NSImage.alloc().initByReferencingFile_(p)
                img.setSize_((20, 20))
                img.setTemplate_(True)
                return img
        return None

    def getToolbarTip(self):
        return "Blobbington"

    def mouseDown(self, point, clickCount):
        self.cursorPos = None
        self.dragPath = [(point.x, point.y)]

    def mouseDragged(self, point, delta):
        self.dragPath.append((point.x, point.y))
        self.refreshView()

    def mouseMoved(self, point, delta=None):
        self.cursorPos = (point.x, point.y)
        self.refreshView()

    def mouseUp(self, point):
        total = 0
        for i in range(1, len(self.dragPath)):
            total += math.hypot(
                self.dragPath[i][0] - self.dragPath[i-1][0],
                self.dragPath[i][1] - self.dragPath[i-1][1]
            )
        if len(self.dragPath) >= 2 and total >= 2:
            self.commitStroke()
        elif self.dragPath:
            rx, ry = self.brushRadii()
            cx, cy = self.dragPath[0]
            self.commitShape(fullOvalGlyph(cx, cy, rx, ry, self.brushAngle))
            print("Stamped single dab")
        self.dragPath = []
        self.refreshView()

    def draw(self, scale):
        rx, ry = self.brushRadii()

        if self.cursorPos and not self.dragPath:
            cx, cy = self.cursorPos
            M = ovalTransform(rx, ry, self.brushAngle)
            AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(0.2, 0.4, 1.0, 0.6).set()
            path = AppKit.NSBezierPath.bezierPath()
            steps = 32
            for i in range(steps + 1):
                t = 2 * math.pi * i / steps
                ox, oy = M(math.cos(t), math.sin(t))
                if i == 0:
                    path.moveToPoint_(AppKit.NSMakePoint(cx + ox, cy + oy))
                else:
                    path.lineToPoint_(AppKit.NSMakePoint(cx + ox, cy + oy))
            path.closePath()
            path.setLineWidth_(scale)
            path.stroke()

        if len(self.dragPath) < 2:
            return

        cl = subsample(self.dragPath, self.fidelity)
        geo = strokeGeometry(cl, rx, ry, self.brushAngle)
        if geo is None:
            return
        left, right, a0, cd0, a1, cd1 = geo

        end_cap = capPolyline(cl[-1][0], cl[-1][1], a1, cd1, rx, ry, self.brushAngle)
        start_cap = capPolyline(cl[0][0], cl[0][1], a0, cd0, rx, ry, self.brushAngle)

        all_points = right + end_cap + list(reversed(left)) + start_cap

        AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(0.2, 0.4, 1.0, 0.4).set()
        path = AppKit.NSBezierPath.bezierPath()
        path.moveToPoint_(AppKit.NSMakePoint(all_points[0][0], all_points[0][1]))
        for pt in all_points[1:]:
            path.lineToPoint_(AppKit.NSMakePoint(pt[0], pt[1]))
        path.closePath()
        path.fill()

    def commitShape(self, srcGlyph):
        if srcGlyph is None:
            return
        glyph = CurrentGlyph()
        if glyph is None:
            print("No glyph open")
            return
        clean = BooleanGlyph()
        clean = clean | BooleanGlyph(srcGlyph)
        before = len(glyph)
        glyph.prepareUndo("Blobbington")
        pen = glyph.getPen()
        clean.draw(pen)
        for contour in list(glyph)[before:]:
            markSmoothPoints(contour)
        glyph.performUndo()
        glyph.changed()

    def commitStroke(self):
        rx, ry = self.brushRadii()
        cl = subsample(self.dragPath, self.fidelity)
        if len(cl) < 2:
            return
        g = buildStrokeGlyph(cl, rx, ry, self.brushAngle)
        self.commitShape(g)
        print(f"Committed stroke with {len(cl)} centerline points")

installTool(BlobbingtonTool())
print("Blobbington tool installed")
