# Blobbington
# A pen for the RoboFont glyph editor.
# Ink model: the mark is every position the nib passed through.
# The nib is swept from each sample to the next, the pieces are merged,
# then the outline is fitted with the fewest curves inside a tolerance
# that scales with the local width of the stroke.
# Stabilizer: the nib trails the cursor on a string and only moves
# when the string goes taut.

from mojo.events import BaseEventTool, installTool
from mojo.extensions import getExtensionDefault, setExtensionDefault
from mojo.roboFont import CurrentGlyph, RGlyph
from booleanOperations.booleanGlyph import BooleanGlyph
from fontTools.pens.basePen import BasePen
from vanilla import FloatingWindow, Slider, TextBox, EditText
import AppKit
import math
import os
import traceback

PREFS = "com.commodityfoundry.blobbington"
DEBUG = False           # True prints stroke numbers to the Output Window

DEFAULT_SIZE = 60
DEFAULT_ANGLE = 0
DEFAULT_ROUNDNESS = 100
DEFAULT_FIDELITY = 5
DEFAULT_STABILIZER = 0

MIN_THICKNESS = 2.0     # thinnest the nib can get, font units
NIB_SAMPLES = 36        # nib polygon resolution

SAMPLE_SPACING = 2.0    # nib travel before taking a new sample
CENTERLINE_TOL = 0.25   # merges samples that add nothing visible, raise for speed

STRING_MAX_PX = 60.0    # string length at Stabilizer 100, in screen points

FIT_TOL_MIN = 0.8       # max error at Accurate, font units
FIT_TOL_STEP = 0.4      # extra error per fidelity step
TOL_WIDTH_CAP = 0.4     # error never exceeds this share of the local half-width
TOL_FLOOR = 0.6         # smallest error allowed anywhere
LINE_FRACTION = 0.35    # runs straighter than this share of the error become lines
CORNER_ANGLE = 50.0     # turns sharper than this stay sharp
CORNER_WINDOW = 3.0     # corner detection scale, times the error
SNAP_ANGLE = 20.0       # line to curve joins closer than this are made tangent

RESAMPLE_STEP = 4.0     # check points along long edges, so straight sides can't bow
TIP_SHARP = 1.0         # nib tips tighter than this radius make crisp corners
TIP_SNAP = 1.5          # how close an outline point must be to a nib tip
TIP_MERGE = 4.0         # corners this close to a nib tip corner are the same corner

SHIFT_MASK = getattr(AppKit, "NSEventModifierFlagShift", 1 << 17)
NONZERO = getattr(AppKit, "NSWindingRuleNonZero", getattr(AppKit, "NSNonZeroWindingRule", 0))

_panel = None


def loadSetting(name, fallback):
    return getExtensionDefault(PREFS + "." + name, fallback)


def saveSetting(name, value):
    setExtensionDefault(PREFS + "." + name, value)


# ---------- vectors

def v_sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def v_add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def v_mul(a, s):
    return (a[0] * s, a[1] * s)


def v_dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def v_len(a):
    return math.hypot(a[0], a[1])


def v_norm(a):
    m = math.hypot(a[0], a[1])
    if m == 0:
        return (0.0, 0.0)
    return (a[0] / m, a[1] / m)


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def segDistSq(p, a, b):
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    L = dx * dx + dy * dy
    if L == 0:
        return (p[0] - a[0]) ** 2 + (p[1] - a[1]) ** 2
    t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L
    t = max(0.0, min(1.0, t))
    qx = a[0] + t * dx
    qy = a[1] + t * dy
    return (p[0] - qx) ** 2 + (p[1] - qy) ** 2


def polyArea(pts):
    a = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def cleanPoly(pts, eps=0.01):
    out = []
    for p in pts:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append(p)
    while len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def resamplePoly(pts, step):
    # adds points along long edges, exactly on the edge
    out = []
    n = len(pts)
    for i in range(n):
        a = pts[i]
        b = pts[(i + 1) % n]
        out.append(a)
        d = dist(a, b)
        if d > step:
            k = int(d / step)
            for j in range(1, k + 1):
                t = j / float(k + 1)
                out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return out


def nearestIndex(pts, q, radius):
    best = None
    bd = radius * radius
    for i, p in enumerate(pts):
        d = (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2
        if d <= bd:
            bd = d
            best = i
    return best


def douglasPeucker(pts, tol):
    n = len(pts)
    if n < 3:
        return list(pts)
    keep = [False] * n
    keep[0] = True
    keep[-1] = True
    tol2 = tol * tol
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        worst = -1.0
        idx = -1
        for k in range(i + 1, j):
            d = segDistSq(pts[k], pts[i], pts[j])
            if d > worst:
                worst = d
                idx = k
        if worst > tol2:
            keep[idx] = True
            stack.append((i, idx))
            stack.append((idx, j))
    return [pts[k] for k in range(n) if keep[k]]


def constrainPoint(origin, pt):
    dx = pt[0] - origin[0]
    dy = pt[1] - origin[1]
    d = math.hypot(dx, dy)
    if d == 0:
        return pt
    ang = round(math.degrees(math.atan2(dy, dx)) / 45.0) * 45.0
    r = math.radians(ang)
    return (origin[0] + math.cos(r) * d, origin[1] + math.sin(r) * d)


def shiftIsDown():
    try:
        return bool(AppKit.NSEvent.modifierFlags() & SHIFT_MASK)
    except Exception:
        return False


# ---------- nib

def ovalTransform(rx, ry, angleDeg):
    a = math.radians(angleDeg)
    c = math.cos(a)
    s = math.sin(a)

    def M(px, py):
        sx = rx * px
        sy = ry * py
        return (sx * c - sy * s, sx * s + sy * c)
    return M


def ovalTransformT(rx, ry, angleDeg):
    a = math.radians(angleDeg)
    c = math.cos(a)
    s = math.sin(a)

    def MT(px, py):
        return (rx * (px * c + py * s), ry * (-px * s + py * c))
    return MT


def convexHull(points):
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def nibOffsets(rx, ry, angleDeg):
    # samples by outward direction (covers the tips) and by angle
    # around the oval (covers the flat sides), then keeps the outline
    M = ovalTransform(rx, ry, angleDeg)
    MT = ovalTransformT(rx, ry, angleDeg)
    pts = []
    for k in range(NIB_SAMPLES):
        a = 2.0 * math.pi * k / NIB_SAMPLES
        tx, ty = MT(math.cos(a), math.sin(a))
        m = math.hypot(tx, ty)
        if m > 0:
            pts.append(M(tx / m, ty / m))
        pts.append(M(math.cos(a), math.sin(a)))
    return convexHull(pts)


def nibAt(offs, p):
    return [(p[0] + ox, p[1] + oy) for ox, oy in offs]


def sweepHull(offs, a, b):
    if dist(a, b) < 1e-9:
        return nibAt(offs, a)
    return convexHull(nibAt(offs, a) + nibAt(offs, b))


# ---------- merge

class PolyPen(BasePen):

    def __init__(self):
        BasePen.__init__(self, None)
        self.contours = []
        self.current = None

    def _moveTo(self, pt):
        self.current = [pt]

    def _lineTo(self, pt):
        self.current.append(pt)

    def _curveToOne(self, p1, p2, p3):
        p0 = self.current[-1]
        for k in range(1, 9):
            t = k / 8.0
            mt = 1.0 - t
            a = mt * mt * mt
            b = 3.0 * mt * mt * t
            c = 3.0 * mt * t * t
            d = t * t * t
            self.current.append((a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0],
                                 a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]))

    def _closePath(self):
        if self.current:
            pts = self.current
            if len(pts) > 1 and pts[-1] == pts[0]:
                pts = pts[:-1]
            self.contours.append(pts)
        self.current = None

    def _endPath(self):
        self._closePath()


def unionPolygons(polys):
    g = RGlyph()
    pen = g.getPen()
    for poly in polys:
        if len(poly) < 3:
            continue
        pen.moveTo(poly[0])
        for p in poly[1:]:
            pen.lineTo(p)
        pen.closePath()
    merged = BooleanGlyph() | BooleanGlyph(g)
    rec = PolyPen()
    merged.draw(rec)
    result = []
    for c in rec.contours:
        c = cleanPoly(c)
        if len(c) >= 3 and abs(polyArea(c)) >= 1.0:
            result.append(c)
    return result


def localHalfWidths(pts, center, reach):
    # distance from each outline point to the centerline, capped at reach
    if len(center) == 1:
        c0 = center[0]
        return [min(reach, dist(p, c0)) for p in pts]
    cell = max(reach, 1.0)
    grid = {}
    for i in range(len(center) - 1):
        a = center[i]
        b = center[i + 1]
        x0 = int(math.floor((min(a[0], b[0]) - reach) / cell))
        x1 = int(math.floor((max(a[0], b[0]) + reach) / cell))
        y0 = int(math.floor((min(a[1], b[1]) - reach) / cell))
        y1 = int(math.floor((max(a[1], b[1]) + reach) / cell))
        for gx in range(x0, x1 + 1):
            for gy in range(y0, y1 + 1):
                grid.setdefault((gx, gy), []).append(i)
    reach2 = reach * reach
    out = []
    for p in pts:
        key = (int(math.floor(p[0] / cell)), int(math.floor(p[1] / cell)))
        best = reach2
        for i in grid.get(key, ()):
            d = segDistSq(p, center[i], center[i + 1])
            if d < best:
                best = d
        out.append(math.sqrt(best))
    return out


# ---------- curve fitting

def bezPoint(b, t):
    mt = 1.0 - t
    a = mt * mt * mt
    c1 = 3.0 * mt * mt * t
    c2 = 3.0 * mt * t * t
    d = t * t * t
    return (a * b[0][0] + c1 * b[1][0] + c2 * b[2][0] + d * b[3][0],
            a * b[0][1] + c1 * b[1][1] + c2 * b[2][1] + d * b[3][1])


def walkIndex(pts, i, step, target):
    d = 0.0
    j = i
    n = len(pts)
    while True:
        k = j + step
        if k < 0 or k >= n:
            return j
        d += dist(pts[k], pts[j])
        j = k
        if d >= target:
            return j


def startTangent(pts, w):
    j = walkIndex(pts, 0, 1, w)
    t = v_norm(v_sub(pts[j], pts[0]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[-1], pts[0]))
    return t


def endTangent(pts, w):
    n = len(pts)
    j = walkIndex(pts, n - 1, -1, w)
    t = v_norm(v_sub(pts[j], pts[n - 1]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[0], pts[n - 1]))
    return t


def centerTangent(pts, i, w):
    a = walkIndex(pts, i, -1, w)
    b = walkIndex(pts, i, 1, w)
    t = v_norm(v_sub(pts[a], pts[b]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[i - 1], pts[i + 1]))
    return t


def chordParams(pts, first, last):
    u = [0.0]
    for i in range(first + 1, last + 1):
        u.append(u[-1] + dist(pts[i], pts[i - 1]))
    total = u[-1]
    if total == 0:
        n = len(u)
        return [k / float(n - 1) for k in range(n)]
    return [x / total for x in u]


def generateBezier(pts, first, last, u, t1, t2):
    p0 = pts[first]
    p3 = pts[last]
    c00 = 0.0
    c01 = 0.0
    c11 = 0.0
    x0 = 0.0
    x1 = 0.0
    for idx in range(len(u)):
        t = u[idx]
        mt = 1.0 - t
        b0 = mt * mt * mt
        b1 = 3.0 * mt * mt * t
        b2 = 3.0 * mt * t * t
        b3 = t * t * t
        a1 = v_mul(t1, b1)
        a2 = v_mul(t2, b2)
        c00 += v_dot(a1, a1)
        c01 += v_dot(a1, a2)
        c11 += v_dot(a2, a2)
        p = pts[first + idx]
        tmp = (p[0] - (p0[0] * (b0 + b1) + p3[0] * (b2 + b3)),
               p[1] - (p0[1] * (b0 + b1) + p3[1] * (b2 + b3)))
        x0 += v_dot(a1, tmp)
        x1 += v_dot(a2, tmp)
    det = c00 * c11 - c01 * c01
    seg = dist(p0, p3)
    alphaL = 0.0
    alphaR = 0.0
    if abs(det) > 1e-12:
        alphaL = (x0 * c11 - x1 * c01) / det
        alphaR = (c00 * x1 - c01 * x0) / det
    eps = 1e-6 * seg
    if alphaL < eps or alphaR < eps or alphaL > seg * 3.0 or alphaR > seg * 3.0:
        d = seg / 3.0
        return (p0, v_add(p0, v_mul(t1, d)), v_add(p3, v_mul(t2, d)), p3)
    return (p0, v_add(p0, v_mul(t1, alphaL)), v_add(p3, v_mul(t2, alphaR)), p3)


def maxError(pts, tols, first, last, bez, u):
    # worst error relative to each point's own tolerance
    worst = 0.0
    split = (first + last) // 2
    for i in range(first + 1, last):
        p = bezPoint(bez, u[i - first])
        d = ((p[0] - pts[i][0]) ** 2 + (p[1] - pts[i][1]) ** 2) / (tols[i] * tols[i])
        if d >= worst:
            worst = d
            split = i
    return worst, split


def reparameterize(pts, first, last, u, bez):
    q1 = [v_mul(v_sub(bez[i + 1], bez[i]), 3.0) for i in range(3)]
    q2 = [v_mul(v_sub(q1[i + 1], q1[i]), 2.0) for i in range(2)]
    out = []
    for idx in range(len(u)):
        t = u[idx]
        p = pts[first + idx]
        qt = bezPoint(bez, t)
        mt = 1.0 - t
        q1t = (mt * mt * q1[0][0] + 2.0 * mt * t * q1[1][0] + t * t * q1[2][0],
               mt * mt * q1[0][1] + 2.0 * mt * t * q1[1][1] + t * t * q1[2][1])
        q2t = (mt * q2[0][0] + t * q2[1][0], mt * q2[0][1] + t * q2[1][1])
        diff = v_sub(qt, p)
        num = v_dot(diff, q1t)
        den = v_dot(q1t, q1t) + v_dot(diff, q2t)
        if abs(den) < 1e-12:
            out.append(t)
        else:
            out.append(max(0.0, min(1.0, t - num / den)))
    return out


def fitsLine(pts, tols, first, last):
    a = pts[first]
    b = pts[last]
    for i in range(first + 1, last):
        lt = LINE_FRACTION * tols[i]
        if segDistSq(pts[i], a, b) > lt * lt:
            return False
    return True


def fitRun(pts, tols, t1=None, t2=None):
    n = len(pts)
    if n < 2:
        return []
    w = max(1.5, 2.0 * max(tols))
    cosSnap = math.cos(math.radians(SNAP_ANGLE))
    if t1 is None:
        t1 = startTangent(pts, w)
    if t2 is None:
        t2 = endTangent(pts, w)
    out = []
    stack = [(0, n - 1, t1, t2)]
    while stack:
        first, last, ta, tb = stack.pop()
        if last <= first:
            continue
        p0 = pts[first]
        p3 = pts[last]

        if dist(p0, p3) < 1e-9:
            if last - first < 2:
                continue
            far = first + 1
            best = -1.0
            for i in range(first + 1, last):
                d = dist(pts[i], p0)
                if d > best:
                    best = d
                    far = i
            tc = centerTangent(pts, far, w)
            stack.append((far, last, v_mul(tc, -1.0), tb))
            stack.append((first, far, ta, tc))
            continue

        if last - first == 1:
            chord = v_norm(v_sub(p3, p0))
            if v_dot(ta, chord) >= cosSnap and v_dot(tb, v_mul(chord, -1.0)) >= cosSnap:
                out.append(("line", p0, None, None, p3))
            else:
                d = dist(p0, p3) / 3.0
                out.append(("curve", p0, v_add(p0, v_mul(ta, d)), v_add(p3, v_mul(tb, d)), p3))
            continue

        if fitsLine(pts, tols, first, last):
            out.append(("line", p0, None, None, p3))
            continue

        u = chordParams(pts, first, last)
        bez = generateBezier(pts, first, last, u, ta, tb)
        worst, split = maxError(pts, tols, first, last, bez, u)
        if worst < 1.0:
            out.append(("curve",) + tuple(bez))
            continue
        if worst < 4.0:
            done = False
            for _ in range(4):
                u = reparameterize(pts, first, last, u, bez)
                bez = generateBezier(pts, first, last, u, ta, tb)
                worst, split = maxError(pts, tols, first, last, bez, u)
                if worst < 1.0:
                    done = True
                    break
            if done:
                out.append(("curve",) + tuple(bez))
                continue
        if split <= first or split >= last:
            split = (first + last) // 2
        tc = centerTangent(pts, split, w)
        stack.append((split, last, v_mul(tc, -1.0), tb))
        stack.append((first, split, ta, tc))
    return out


def closedWalk(pts, i, step, target):
    n = len(pts)
    d = 0.0
    j = i
    for _ in range(n - 1):
        k = (j + step) % n
        d += dist(pts[k], pts[j])
        j = k
        if d >= target:
            break
    return j


def closedTangent(pts, i, w):
    n = len(pts)
    a = closedWalk(pts, i, -1, w)
    b = closedWalk(pts, i, 1, w)
    t = v_norm(v_sub(pts[a], pts[b]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[(i - 1) % n], pts[(i + 1) % n]))
    return t


def findOutlineCorners(pts, w, total):
    n = len(pts)
    if n < 4:
        return []
    turns = []
    for i in range(n):
        a = closedWalk(pts, i, -1, w)
        b = closedWalk(pts, i, 1, w)
        v1 = v_norm(v_sub(pts[i], pts[a]))
        v2 = v_norm(v_sub(pts[b], pts[i]))
        if v1 == (0.0, 0.0) or v2 == (0.0, 0.0):
            turns.append(0.0)
            continue
        cosv = max(-1.0, min(1.0, v_dot(v1, v2)))
        turns.append(math.degrees(math.acos(cosv)))
    cum = [0.0]
    for i in range(1, n):
        cum.append(cum[-1] + dist(pts[i], pts[i - 1]))
    cands = [i for i in range(n) if turns[i] >= CORNER_ANGLE]
    cands.sort(key=lambda i: -turns[i])
    chosen = []
    for i in cands:
        ok = True
        for k in chosen:
            d = abs(cum[i] - cum[k])
            d = min(d, total - d)
            if d < w:
                ok = False
                break
        if ok:
            chosen.append(i)
    chosen.sort()
    return chosen


def fitClosed(pts, tols, globalTol, tipPoints):
    n = len(pts)
    if n < 3:
        return [], set()
    cum = [0.0]
    for i in range(1, n):
        cum.append(cum[-1] + dist(pts[i], pts[i - 1]))
    total = cum[-1] + dist(pts[-1], pts[0])
    if total <= 0:
        return [], set()
    w = min(max(1.5, CORNER_WINDOW * globalTol), total / 8.0)
    corners = findOutlineCorners(pts, w, total)

    if tipPoints:
        tipIdx = []
        for q in tipPoints:
            k = nearestIndex(pts, q, TIP_SNAP)
            if k is not None and k not in tipIdx:
                tipIdx.append(k)
        merged = list(tipIdx)
        for c in corners:
            near = False
            for k in tipIdx:
                d = abs(cum[c] - cum[k])
                d = min(d, total - d)
                if d < TIP_MERGE:
                    near = True
                    break
            if not near:
                merged.append(c)
        corners = sorted(set(merged))

    cornerPts = set(pts[c] for c in corners)

    if not corners:
        tw = min(max(1.0, 2.0 * globalTol), total / 8.0)
        tc = closedTangent(pts, 0, tw)
        run = list(pts) + [pts[0]]
        runTols = list(tols) + [tols[0]]
        return fitRun(run, runTols, v_mul(tc, -1.0), tc), cornerPts

    segs = []
    count = len(corners)
    for j in range(count):
        c = corners[j]
        nc = corners[(j + 1) % count]
        if nc > c:
            run = pts[c:nc + 1]
            runTols = tols[c:nc + 1]
        else:
            run = pts[c:] + pts[:nc + 1]
            runTols = tols[c:] + tols[:nc + 1]
        segs.extend(fitRun(run, runTols))
    return segs, cornerPts


def curveIsStraight(s, eps=0.25):
    e2 = eps * eps
    return segDistSq(s[2], s[1], s[4]) <= e2 and segDistSq(s[3], s[1], s[4]) <= e2


def tidySegments(segs, cornerPts):
    out = []
    cos3 = math.cos(math.radians(3.0))
    for s in segs:
        if s[0] == "curve" and curveIsStraight(s):
            s = ("line", s[1], None, None, s[4])
        if out and s[0] == "line" and out[-1][0] == "line":
            a = v_norm(v_sub(out[-1][4], out[-1][1]))
            b = v_norm(v_sub(s[4], s[1]))
            if v_dot(a, b) >= cos3:
                out[-1] = ("line", out[-1][1], None, None, s[4])
                continue
        out.append(s)
    n = len(out)
    cosSnap = math.cos(math.radians(SNAP_ANGLE))
    for i in range(n):
        a = out[i]
        j = (i + 1) % n
        b = out[j]
        if b[1] in cornerPts:
            continue
        if a[0] == "line" and b[0] == "curve":
            L = v_norm(v_sub(a[4], a[1]))
            h = v_sub(b[2], b[1])
            hl = v_len(h)
            if hl > 0 and v_dot(L, v_norm(h)) >= cosSnap:
                out[j] = ("curve", b[1], v_add(b[1], v_mul(L, hl)), b[3], b[4])
        elif a[0] == "curve" and b[0] == "line":
            L = v_norm(v_sub(b[4], b[1]))
            back = v_mul(L, -1.0)
            h = v_sub(a[3], a[4])
            hl = v_len(h)
            if hl > 0 and v_dot(back, v_norm(h)) >= cosSnap:
                out[i] = ("curve", a[1], a[2], v_add(a[4], v_mul(back, hl)), a[4])
    return out


def drawSegments(pen, segs):
    start = segs[0][1]
    pen.moveTo(start)
    last = len(segs) - 1
    for idx in range(len(segs)):
        s = segs[idx]
        if s[0] == "line":
            if idx == last and dist(s[4], start) < 1e-9:
                continue
            pen.lineTo(s[4])
        else:
            pen.curveTo(s[2], s[3], s[4])
    pen.closePath()


def markSmooth(contour, tolDeg=12.0):
    pts = contour.points
    n = len(pts)
    for i, pt in enumerate(pts):
        if pt.type == "offcurve":
            continue
        prev = pts[(i - 1) % n]
        nxt = pts[(i + 1) % n]
        if prev.type != "offcurve" and nxt.type != "offcurve":
            continue
        a = v_norm((pt.x - prev.x, pt.y - prev.y))
        b = v_norm((nxt.x - pt.x, nxt.y - pt.y))
        if a == (0.0, 0.0) or b == (0.0, 0.0):
            continue
        cosv = max(-1.0, min(1.0, v_dot(a, b)))
        if math.degrees(math.acos(cosv)) < tolDeg:
            pt.smooth = True


# ---------- icon

def fallbackIcon():
    try:
        img = AppKit.NSImage.alloc().initWithSize_((20, 20))
        img.lockFocus()
        AppKit.NSColor.blackColor().set()
        t = AppKit.NSAffineTransform.transform()
        t.translateXBy_yBy_(10, 10)
        t.rotateByDegrees_(35)
        t.concat()
        AppKit.NSBezierPath.bezierPathWithOvalInRect_(((-8.5, -3.0), (17.0, 6.0))).fill()
        img.unlockFocus()
        img.setTemplate_(True)
        return img
    except Exception:
        return None


def loadIcon():
    candidates = []
    here = globals().get("__file__")
    if here:
        candidates.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(here))),
                                       "resources", "icon.pdf"))
    try:
        from mojo.extensions import ExtensionBundle
        rp = ExtensionBundle("Blobbington").resourcesPath()
        if rp:
            candidates.append(os.path.join(rp, "icon.pdf"))
    except Exception:
        pass
    candidates.append(os.path.expanduser(
        "~/Library/Application Support/RoboFont/plugins/Blobbington.roboFontExt/resources/icon.pdf"))
    for p in candidates:
        try:
            if p and os.path.exists(p):
                img = AppKit.NSImage.alloc().initByReferencingFile_(p)
                if img is not None:
                    img.setSize_((20, 20))
                    img.setTemplate_(True)
                    return img
        except Exception:
            pass
    return fallbackIcon()


# ---------- panel

class BlobbingtonPanel(object):

    def __init__(self, tool):
        self.tool = tool
        self.w = FloatingWindow((260, 296), "Blobbington")

        self.w.fidelityLabel = TextBox((10, 10, 240, 20), "Fidelity")
        self.w.fidelitySlider = Slider(
            (10, 28, 240, 23), minValue=1, maxValue=20, value=tool.fidelity,
            tickMarkCount=5, callback=self.fidelityChanged)
        self.w.accurateLabel = TextBox((10, 52, 120, 14), "Accurate", sizeStyle="small")
        self.w.smoothLabel = TextBox((130, 52, 120, 14), "Smooth", alignment="right", sizeStyle="small")

        self.w.sizeLabel = TextBox((10, 80, 90, 20), "Size")
        self.w.sizeField = EditText(
            (195, 78, 55, 22), text=str(tool.brushSize),
            continuous=False, callback=self.sizeTyped)
        self.w.sizeSlider = Slider(
            (10, 102, 240, 20), minValue=4, maxValue=400, value=tool.brushSize,
            callback=self.sizeChanged)

        self.w.angleLabel = TextBox((10, 132, 90, 20), "Angle")
        self.w.angleField = EditText(
            (195, 130, 55, 22), text=str(tool.brushAngle),
            continuous=False, callback=self.angleTyped)
        self.w.angleSlider = Slider(
            (10, 154, 240, 20), minValue=0, maxValue=360, value=tool.brushAngle,
            callback=self.angleChanged)

        self.w.roundnessLabel = TextBox((10, 184, 90, 20), "Roundness")
        self.w.roundnessField = EditText(
            (195, 182, 55, 22), text=str(tool.brushRoundness),
            continuous=False, callback=self.roundnessTyped)
        self.w.roundnessSlider = Slider(
            (10, 206, 240, 20), minValue=1, maxValue=100, value=tool.brushRoundness,
            callback=self.roundnessChanged)

        self.w.stabilizerLabel = TextBox((10, 236, 90, 20), "Stabilizer")
        self.w.stabilizerField = EditText(
            (195, 234, 55, 22), text=str(tool.stabilizer),
            continuous=False, callback=self.stabilizerTyped)
        self.w.stabilizerSlider = Slider(
            (10, 258, 240, 20), minValue=0, maxValue=100, value=tool.stabilizer,
            callback=self.stabilizerChanged)

        self.w.bind("close", self.windowClosed)
        self.w.open()

    def windowClosed(self, sender):
        global _panel
        _panel = None

    def syncToTool(self, tool):
        self.tool = tool
        self.w.fidelitySlider.set(tool.fidelity)
        self.w.sizeSlider.set(tool.brushSize)
        self.w.sizeField.set(str(tool.brushSize))
        self.w.angleSlider.set(tool.brushAngle)
        self.w.angleField.set(str(tool.brushAngle))
        self.w.roundnessSlider.set(tool.brushRoundness)
        self.w.roundnessField.set(str(tool.brushRoundness))
        self.w.stabilizerSlider.set(tool.stabilizer)
        self.w.stabilizerField.set(str(tool.stabilizer))

    def readField(self, sender, lo, hi, current):
        raw = sender.get().strip().replace("%", "")
        try:
            val = int(round(float(raw)))
        except ValueError:
            sender.set(str(current))
            return None
        val = max(lo, min(hi, val))
        sender.set(str(val))
        return val

    def fidelityChanged(self, sender):
        val = int(sender.get())
        self.tool.fidelity = val
        saveSetting("fidelity", val)

    def sizeChanged(self, sender):
        val = int(sender.get())
        self.tool.brushSize = val
        saveSetting("size", val)
        self.w.sizeField.set(str(val))

    def sizeTyped(self, sender):
        val = self.readField(sender, 4, 400, self.tool.brushSize)
        if val is None:
            return
        self.tool.brushSize = val
        saveSetting("size", val)
        self.w.sizeSlider.set(val)

    def angleChanged(self, sender):
        val = int(sender.get())
        self.tool.brushAngle = val
        saveSetting("angle", val)
        self.w.angleField.set(str(val))

    def angleTyped(self, sender):
        val = self.readField(sender, 0, 360, self.tool.brushAngle)
        if val is None:
            return
        self.tool.brushAngle = val
        saveSetting("angle", val)
        self.w.angleSlider.set(val)

    def roundnessChanged(self, sender):
        val = int(sender.get())
        self.tool.brushRoundness = val
        saveSetting("roundness", val)
        self.w.roundnessField.set(str(val))

    def roundnessTyped(self, sender):
        val = self.readField(sender, 1, 100, self.tool.brushRoundness)
        if val is None:
            return
        self.tool.brushRoundness = val
        saveSetting("roundness", val)
        self.w.roundnessSlider.set(val)

    def stabilizerChanged(self, sender):
        val = int(sender.get())
        self.tool.stabilizer = val
        saveSetting("stabilizer", val)
        self.w.stabilizerField.set(str(val))

    def stabilizerTyped(self, sender):
        val = self.readField(sender, 0, 100, self.tool.stabilizer)
        if val is None:
            return
        self.tool.stabilizer = val
        saveSetting("stabilizer", val)
        self.w.stabilizerSlider.set(val)


# ---------- tool

class BlobbingtonTool(BaseEventTool):

    def setup(self):
        self.path = []
        self.offsets = []
        self.preview = None
        self.cursor = None
        self.brushPos = None
        self.dragCursor = None
        self.viewScale = 1.0
        self.reloadSettings()

    def reloadSettings(self):
        self.fidelity = int(loadSetting("fidelity", DEFAULT_FIDELITY))
        self.brushSize = int(loadSetting("size", DEFAULT_SIZE))
        self.brushAngle = int(loadSetting("angle", DEFAULT_ANGLE))
        self.brushRoundness = int(loadSetting("roundness", DEFAULT_ROUNDNESS))
        self.stabilizer = int(loadSetting("stabilizer", DEFAULT_STABILIZER))

    def becomeActive(self):
        global _panel
        self.reloadSettings()
        if _panel is None:
            _panel = BlobbingtonPanel(self)
        else:
            _panel.syncToTool(self)

    def becomeInactive(self):
        global _panel
        self.path = []
        self.preview = None
        self.cursor = None
        self.brushPos = None
        self.dragCursor = None
        if _panel is not None:
            p = _panel
            _panel = None
            try:
                p.w.close()
            except Exception:
                pass

    def brushRadii(self):
        rx = self.brushSize / 2.0
        ry = rx * (self.brushRoundness / 100.0)
        ry = max(ry, min(MIN_THICKNESS / 2.0, rx))
        return rx, ry

    def stringLength(self):
        return (self.stabilizer / 100.0) * STRING_MAX_PX * self.viewScale

    def getToolbarIcon(self):
        return loadIcon()

    def getToolbarTip(self):
        return "Blobbington"

    def addPreview(self, poly):
        if len(poly) < 3:
            return
        if self.preview is None:
            self.preview = AppKit.NSBezierPath.bezierPath()
            self.preview.setWindingRule_(NONZERO)
        bp = self.preview
        bp.moveToPoint_(AppKit.NSMakePoint(poly[0][0], poly[0][1]))
        for q in poly[1:]:
            bp.lineToPoint_(AppKit.NSMakePoint(q[0], q[1]))
        bp.closePath()

    def mouseDown(self, point, clickCount):
        rx, ry = self.brushRadii()
        self.offsets = nibOffsets(rx, ry, self.brushAngle)
        p = (point.x, point.y)
        self.path = [p]
        self.brushPos = p
        self.dragCursor = p
        self.preview = None
        self.addPreview(nibAt(self.offsets, p))
        self.cursor = None
        self.refreshView()

    def mouseDragged(self, point, delta):
        if not self.path:
            return
        p = (point.x, point.y)
        self.dragCursor = p
        if shiftIsDown():
            start = self.path[0]
            end = constrainPoint(start, p)
            self.path = [start, end]
            self.brushPos = end
            self.preview = None
            self.addPreview(sweepHull(self.offsets, start, end))
        else:
            b = self.brushPos if self.brushPos is not None else p
            R = self.stringLength()
            d = dist(b, p)
            if R <= 0:
                nb = p
            elif d > R:
                t = (d - R) / d
                nb = (b[0] + (p[0] - b[0]) * t, b[1] + (p[1] - b[1]) * t)
            else:
                nb = b
            self.brushPos = nb
            last = self.path[-1]
            if dist(nb, last) >= SAMPLE_SPACING:
                self.path.append(nb)
                self.addPreview(sweepHull(self.offsets, last, nb))
        self.refreshView()

    def mouseMoved(self, point, delta=None):
        self.cursor = (point.x, point.y)
        self.refreshView()

    def mouseUp(self, point):
        if self.path and not shiftIsDown():
            if self.stringLength() > 0 and self.brushPos is not None:
                end = self.brushPos
            else:
                end = (point.x, point.y)
            if dist(end, self.path[-1]) > 0.5:
                self.path.append(end)
        try:
            self.commit()
        except Exception:
            print("Blobbington: stroke failed. Please report this:")
            print(traceback.format_exc())
        self.path = []
        self.preview = None
        self.brushPos = None
        self.dragCursor = None
        self.refreshView()

    def strokeNib(self, pos, scale, offs=None):
        if offs is None:
            rx, ry = self.brushRadii()
            offs = nibOffsets(rx, ry, self.brushAngle)
        poly = nibAt(offs, pos)
        if len(poly) < 3:
            return
        bp = AppKit.NSBezierPath.bezierPath()
        bp.moveToPoint_(AppKit.NSMakePoint(poly[0][0], poly[0][1]))
        for q in poly[1:]:
            bp.lineToPoint_(AppKit.NSMakePoint(q[0], q[1]))
        bp.closePath()
        bp.setLineWidth_(scale)
        AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(0.2, 0.4, 1.0, 0.6).set()
        bp.stroke()

    def draw(self, scale):
        if scale:
            self.viewScale = scale
        if self.preview is not None:
            AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(0.2, 0.4, 1.0, 0.45).set()
            self.preview.fill()
            if self.brushPos is not None:
                self.strokeNib(self.brushPos, scale, self.offsets)
                if self.stabilizer > 0 and self.dragCursor is not None:
                    b = self.brushPos
                    c = self.dragCursor
                    AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(0.2, 0.4, 1.0, 0.8).set()
                    if dist(b, c) > 0:
                        line = AppKit.NSBezierPath.bezierPath()
                        line.moveToPoint_(AppKit.NSMakePoint(b[0], b[1]))
                        line.lineToPoint_(AppKit.NSMakePoint(c[0], c[1]))
                        line.setLineWidth_(scale)
                        line.stroke()
                    r = 3.0 * scale
                    AppKit.NSBezierPath.bezierPathWithOvalInRect_(((c[0] - r, c[1] - r), (2 * r, 2 * r))).fill()
        elif self.cursor is not None:
            self.strokeNib(self.cursor, scale)

    def commit(self):
        if not self.path:
            return
        glyph = CurrentGlyph()
        if glyph is None:
            return
        rx, ry = self.brushRadii()
        offs = nibOffsets(rx, ry, self.brushAngle)
        center = douglasPeucker(self.path, CENTERLINE_TOL)
        if len(center) < 2:
            polys = [nibAt(offs, center[0])]
        else:
            polys = [sweepHull(offs, center[i], center[i + 1]) for i in range(len(center) - 1)]

        outline = unionPolygons(polys)

        tipPoints = []
        if ry * ry / rx < TIP_SHARP:
            tx, ty = ovalTransform(rx, ry, self.brushAngle)(1.0, 0.0)
            for c in (center[0], center[-1]):
                tipPoints.append((c[0] + tx, c[1] + ty))
                tipPoints.append((c[0] - tx, c[1] - ty))

        globalTol = FIT_TOL_MIN + (self.fidelity - 1) * FIT_TOL_STEP
        reach = globalTol / TOL_WIDTH_CAP

        fitted = []
        outlinePts = 0
        thinnest = globalTol
        for poly in outline:
            poly = resamplePoly(poly, RESAMPLE_STEP)
            outlinePts += len(poly)
            halfWidths = localHalfWidths(poly, center, reach)
            tols = [min(globalTol, max(TOL_FLOOR, TOL_WIDTH_CAP * h)) for h in halfWidths]
            if tols:
                thinnest = min(thinnest, min(tols))
            segs, cornerPts = fitClosed(poly, tols, globalTol, tipPoints)
            segs = tidySegments(segs, cornerPts)
            if len(segs) >= 2:
                fitted.append(segs)

        if not fitted:
            return

        before = len(glyph)
        glyph.prepareUndo("Blobbington")
        pen = glyph.getPen()
        for segs in fitted:
            drawSegments(pen, segs)
        for contour in list(glyph)[before:]:
            markSmooth(contour)
        glyph.performUndo()
        glyph.changed()

        if DEBUG:
            segCount = sum(len(s) for s in fitted)
            lineCount = sum(1 for s in fitted for seg in s if seg[0] == "line")
            print("Blobbington: %d samples, %d centerline, %d outline pts -> %d segments (%d straight), tol %.1f, thin parts %.1f, stabilizer %d"
                  % (len(self.path), len(center), outlinePts, segCount, lineCount, globalTol, thinnest, self.stabilizer))


installTool(BlobbingtonTool())
