"""
Blobbington
===========

A pen for the RoboFont glyph editor. Drag to draw with an oval nib: the
mark is exactly where the nib travelled, like ink on paper, and it is
committed to the glyph as clean, editable contours. A single click stamps
one dab.

This file is the RoboFont side: the tool, its settings panel and its live
preview. All the geometry lives in `blobbingtonEngine.py`, next to this
file, which has no RoboFont dependencies and can be tested on its own.

- The preview is drawn with merz layers in the glyph editor's foreground,
  obtained with `extensionContainer()`. Nothing is redrawn by hand.
- The panel is an ezui `EZPanel`. It opens when the tool is selected and
  closes when another tool is selected.
- Settings are stored as one dictionary with `mojo.extensions` defaults.

Controls
--------
Fidelity    how many points the finished outline uses (Accurate to Smooth)
Size        length of the nib, in font units
Angle       rotation of the nib, in degrees
Roundness   100 is a round marker, 1 is a flat broad nib
Stabilizer  the nib trails the cursor on a string, smoothing out wobble
Shift       locks the stroke to 45 and 90 degree directions

Made by Ry Sunday Faraola, Commodity Foundry.
"""

import math
import os
import sys
import traceback

import ezui
from AppKit import NSImage
from merz import MerzPen
from mojo.events import BaseEventTool, installTool
from mojo.extensions import getExtensionDefault, setExtensionDefault


def _libFolder():
    """The folder this file lives in, so the engine next to it can be imported."""
    here = globals().get("__file__")
    if here:
        return os.path.dirname(os.path.abspath(here))
    return os.path.expanduser(
        "~/Library/Application Support/RoboFont/plugins/Blobbington.roboFontExt/lib")


LIB_FOLDER = _libFolder()
if LIB_FOLDER not in sys.path:
    sys.path.insert(0, LIB_FOLDER)

import blobbingtonEngine as engine  # noqa: E402


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

TOOL_IDENTIFIER = "com.commodityfoundry.blobbington"
SETTINGS_KEY = TOOL_IDENTIFIER + ".settings"
LEGACY_PREFIX = TOOL_IDENTIFIER + "."   # per-setting keys used before version 2.1

DEBUG = False           # True prints stroke statistics to the Output Window

DEFAULT_SETTINGS = dict(
    fidelity=5,
    size=60,
    angle=0,
    roundness=100,
    stabilizer=0,
)


def loadSettings():
    """
    Read the stored settings, falling back to defaults. Settings saved by
    earlier versions, one key per setting, are picked up the first time.
    """
    settings = dict(DEFAULT_SETTINGS)
    stored = getExtensionDefault(SETTINGS_KEY, fallback=None)
    if stored is not None:
        for key in DEFAULT_SETTINGS:
            try:
                settings[key] = stored[key]
            except (KeyError, TypeError, IndexError):
                pass
    else:
        for key in DEFAULT_SETTINGS:
            value = getExtensionDefault(LEGACY_PREFIX + key, fallback=None)
            if value is not None:
                settings[key] = value
    return settings


def saveSettings(settings):
    """Store the settings as a single dictionary."""
    setExtensionDefault(SETTINGS_KEY, {key: settings[key] for key in DEFAULT_SETTINGS})


# ---------------------------------------------------------------------------
# Nib and preview constants
# ---------------------------------------------------------------------------

MIN_THICKNESS = 2.0         # thinnest the nib can get, font units
SAMPLE_SPACING = 2.0        # nib travel between stroke samples, font units
STRING_MAX_POINTS = 60.0    # stabilizer string length at 100, in screen points

PREVIEW_COLOR = (0.2, 0.4, 1.0, 1.0)
INK_OPACITY = 0.45          # the in-progress ink is drawn opaque inside a
                            # translucent group, so overlaps don't darken
OUTLINE_COLOR = (0.2, 0.4, 1.0, 0.8)
CHUNK_SIZE = 24             # swept pieces per preview layer; full layers are
                            # left as they are, so each mouse event only
                            # rebuilds one small path


def brushRadii(settings):
    """The nib's long and short radii, in font units, from the settings."""
    rx = float(settings["size"]) / 2.0
    ry = rx * float(settings["roundness"]) / 100.0
    ry = max(ry, min(MIN_THICKNESS / 2.0, rx))
    return rx, ry


def polygonsPath(polygons):
    """A CGPath containing the given closed polygons, built with a MerzPen."""
    pen = MerzPen()
    for poly in polygons:
        if len(poly) < 3:
            continue
        pen.moveTo(poly[0])
        for pt in poly[1:]:
            pen.lineTo(pt)
        pen.closePath()
    return pen.path


def linePath(start, end):
    """A CGPath for a single open line."""
    pen = MerzPen()
    pen.moveTo(start)
    pen.lineTo(end)
    pen.endPath()
    return pen.path


def markSmooth(contour, toleranceDegrees=12.0):
    """
    Mark on-curve points smooth where the path passes straight through them,
    so they behave as smooth points when edited.
    """
    points = contour.points
    count = len(points)
    for i, point in enumerate(points):
        if point.type == "offcurve":
            continue
        prev = points[(i - 1) % count]
        nxt = points[(i + 1) % count]
        if prev.type != "offcurve" and nxt.type != "offcurve":
            continue
        a = engine.v_norm((point.x - prev.x, point.y - prev.y))
        b = engine.v_norm((nxt.x - point.x, nxt.y - point.y))
        if a == (0.0, 0.0) or b == (0.0, 0.0):
            continue
        cosine = max(-1.0, min(1.0, engine.v_dot(a, b)))
        if math.degrees(math.acos(cosine)) < toleranceDegrees:
            point.smooth = True


def loadToolbarIcon():
    """The toolbar icon from the extension's resources folder, as a template image."""
    path = os.path.join(os.path.dirname(LIB_FOLDER), "resources", "icon.pdf")
    if not os.path.exists(path):
        return None
    image = NSImage.alloc().initByReferencingFile_(path)
    if image is None:
        return None
    image.setSize_((20, 20))
    image.setTemplate_(True)
    return image


# ---------------------------------------------------------------------------
# Panel
# ---------------------------------------------------------------------------

class BlobbingtonPanel(ezui.WindowController):
    """
    The floating settings panel. Every change is saved immediately and
    passed to the tool, so the preview updates while a slider moves.
    """

    def build(self):
        self.tool = None
        content = """
        * TwoColumnForm       @form
        > : Fidelity:
        > ---X---             @fidelity
        > :
        > Accurate to Smooth
        > : Size:
        > ---X--- [__]        @size
        > : Angle:
        > ---X--- [__]        @angle
        > : Roundness:
        > ---X--- [__]        @roundness
        > : Stabilizer:
        > ---X--- [__]        @stabilizer
        """
        descriptionData = dict(
            form=dict(
                titleColumnWidth=76,
                itemColumnWidth=200,
            ),
            fidelity=dict(
                minValue=1,
                maxValue=20,
                value=DEFAULT_SETTINGS["fidelity"],
                tickMarks=5,
                continuous=True,
            ),
            size=dict(
                valueType="integer",
                minValue=4,
                maxValue=400,
                value=DEFAULT_SETTINGS["size"],
                continuous=True,
            ),
            angle=dict(
                valueType="integer",
                minValue=0,
                maxValue=360,
                value=DEFAULT_SETTINGS["angle"],
                continuous=True,
            ),
            roundness=dict(
                valueType="integer",
                minValue=1,
                maxValue=100,
                value=DEFAULT_SETTINGS["roundness"],
                continuous=True,
            ),
            stabilizer=dict(
                valueType="integer",
                minValue=0,
                maxValue=100,
                value=DEFAULT_SETTINGS["stabilizer"],
                continuous=True,
            ),
        )
        self.w = ezui.EZPanel(
            title="Blobbington",
            content=content,
            descriptionData=descriptionData,
            controller=self,
        )
        self.w.setItemValues(loadSettings())

    def started(self):
        self.w.open()

    def destroy(self):
        tool = self.tool
        self.tool = None
        if tool is not None:
            tool.panelClosed()

    def settingsFromPanel(self):
        """The current panel values as a settings dictionary."""
        settings = loadSettings()
        values = self.w.getItemValues()
        for key in DEFAULT_SETTINGS:
            if key in values and values[key] is not None:
                settings[key] = values[key]
        settings["fidelity"] = int(round(float(settings["fidelity"])))
        return settings

    def settingsChanged(self):
        settings = self.settingsFromPanel()
        saveSettings(settings)
        if self.tool is not None:
            self.tool.settingsChanged(settings)

    def fidelityCallback(self, sender):
        self.settingsChanged()

    def sizeCallback(self, sender):
        self.settingsChanged()

    def angleCallback(self, sender):
        self.settingsChanged()

    def roundnessCallback(self, sender):
        self.settingsChanged()

    def stabilizerCallback(self, sender):
        self.settingsChanged()


# ---------------------------------------------------------------------------
# Tool
# ---------------------------------------------------------------------------

class BlobbingtonTool(BaseEventTool):
    """
    The glyph editor tool.

    While drawing, each new stroke sample adds one swept piece of ink to
    the preview. On mouse up the samples go to the engine, and the fitted
    contours are added to the glyph as a single undo step.
    """

    # ---- setup and lifecycle ----

    def setup(self):
        self.settings = loadSettings()
        self.panel = None
        self.samples = []
        self.brushPoint = None
        self.dragPoint = None
        self.offsets = []
        self.chunkHulls = []
        self.chunkLayer = None
        self.inkLayer = None
        self.nibLayer = None
        self.stringLayer = None
        try:
            container = self.extensionContainer(
                identifier=TOOL_IDENTIFIER,
                location="foreground",
                clear=True,
            )
        except Exception:
            print("Blobbington: could not create the preview layers.")
            print(traceback.format_exc())
            return
        # the in-progress ink: one path layer per chunk of swept pieces
        self.inkLayer = container.appendBaseSublayer(visible=True)
        self.inkLayer.setOpacity(INK_OPACITY)
        # the nib outline, following the cursor or the pen while drawing
        self.nibLayer = container.appendPathSublayer(
            fillColor=None,
            strokeColor=OUTLINE_COLOR,
            strokeWidth=1,
            visible=False,
        )
        # the stabilizer string between the cursor and the nib
        self.stringLayer = container.appendPathSublayer(
            fillColor=None,
            strokeColor=OUTLINE_COLOR,
            strokeWidth=1,
            visible=False,
        )
        for layer in (self.nibLayer, self.stringLayer):
            try:
                layer.setStrokeWidthIsVisuallyConstant(True)
            except AttributeError:
                pass
        self.rebuildNib()

    def becomeActive(self):
        self.settingsChanged(loadSettings())
        self.openPanel()

    def becomeInactive(self):
        self.clearStroke()
        if self.nibLayer is not None:
            self.nibLayer.setVisible(False)
        self.closePanel()

    def viewDidChangeGlyph(self):
        self.clearStroke()

    def getToolbarIcon(self):
        return loadToolbarIcon()

    def getToolbarTip(self):
        return "Blobbington"

    # ---- panel ----

    def openPanel(self):
        if self.panel is not None:
            return
        self.panel = BlobbingtonPanel()
        self.panel.tool = self

    def closePanel(self):
        panel = self.panel
        self.panel = None
        if panel is None:
            return
        panel.tool = None
        try:
            panel.w.close()
        except Exception:
            pass

    def panelClosed(self):
        """Called by the panel when the user closes it."""
        self.panel = None

    def settingsChanged(self, settings):
        self.settings = settings
        self.rebuildNib()

    # ---- preview ----

    def rebuildNib(self):
        """Recompute the nib polygon and redraw its outline around (0, 0)."""
        rx, ry = brushRadii(self.settings)
        self.offsets = engine.nibOffsets(rx, ry, self.settings["angle"])
        if self.nibLayer is not None:
            self.nibLayer.setPath(polygonsPath([self.offsets]))

    def showNibAt(self, point):
        if self.nibLayer is None:
            return
        with self.nibLayer.propertyGroup():
            self.nibLayer.setPosition(point)
            self.nibLayer.setVisible(True)

    def showString(self):
        if self.stringLayer is None:
            return
        visible = (
            self.stringLength() > 0
            and self.brushPoint is not None
            and self.dragPoint is not None
            and engine.dist(self.brushPoint, self.dragPoint) > 0
        )
        if visible:
            self.stringLayer.setPath(linePath(self.brushPoint, self.dragPoint))
        self.stringLayer.setVisible(visible)

    def addInk(self, polygon):
        """Add one swept piece to the preview."""
        if self.inkLayer is None or len(polygon) < 3:
            return
        self.chunkHulls.append(polygon)
        if self.chunkLayer is None:
            self.chunkLayer = self.inkLayer.appendPathSublayer(fillColor=PREVIEW_COLOR)
        self.chunkLayer.setPath(polygonsPath(self.chunkHulls))
        if len(self.chunkHulls) >= CHUNK_SIZE:
            # this chunk is complete; the next piece starts a new layer
            self.chunkHulls = []
            self.chunkLayer = None

    def clearInk(self):
        self.chunkHulls = []
        self.chunkLayer = None
        if self.inkLayer is not None:
            self.inkLayer.clearSublayers()

    def clearStroke(self):
        self.samples = []
        self.brushPoint = None
        self.dragPoint = None
        self.clearInk()
        if self.stringLayer is not None:
            self.stringLayer.setVisible(False)

    # ---- stabilizer ----

    def viewScale(self):
        """Screen points per font unit in the glyph editor."""
        try:
            scale = self.inkLayer.getContainer().getContainerScale()
            if scale:
                return float(scale)
        except Exception:
            pass
        return 1.0

    def stringLength(self):
        """The stabilizer string in font units, constant on screen at any zoom."""
        stabilizer = float(self.settings.get("stabilizer", 0))
        if stabilizer <= 0:
            return 0.0
        return (stabilizer / 100.0) * STRING_MAX_POINTS / self.viewScale()

    def pullBrush(self, cursor):
        """
        Move the nib towards the cursor only when the string is taut, so it
        trails behind and small wobbles never reach the ink.
        """
        brush = self.brushPoint if self.brushPoint is not None else cursor
        length = self.stringLength()
        distance = engine.dist(brush, cursor)
        if length <= 0:
            return cursor
        if distance <= length:
            return brush
        t = (distance - length) / distance
        return (brush[0] + (cursor[0] - brush[0]) * t,
                brush[1] + (cursor[1] - brush[1]) * t)

    # ---- mouse ----

    def mouseMoved(self, point, delta=None):
        if not self.samples:
            self.showNibAt((point.x, point.y))

    def mouseDown(self, point, clickCount):
        start = (point.x, point.y)
        self.clearStroke()
        self.samples = [start]
        self.brushPoint = start
        self.dragPoint = start
        self.addInk(engine.nibAt(self.offsets, start))
        self.showNibAt(start)

    def mouseDragged(self, point, delta):
        if not self.samples:
            return
        cursor = (point.x, point.y)
        self.dragPoint = cursor
        if self.shiftDown:
            # a straight stroke from the start, snapped to 45 degree steps
            start = self.samples[0]
            end = engine.constrainPoint(start, cursor)
            self.samples = [start, end]
            self.brushPoint = end
            self.clearInk()
            self.addInk(engine.sweepHull(self.offsets, start, end))
        else:
            brush = self.pullBrush(cursor)
            self.brushPoint = brush
            last = self.samples[-1]
            if engine.dist(brush, last) >= SAMPLE_SPACING:
                self.samples.append(brush)
                self.addInk(engine.sweepHull(self.offsets, last, brush))
        self.showNibAt(self.brushPoint)
        self.showString()

    def mouseUp(self, point):
        if self.samples and not self.shiftDown:
            if self.stringLength() > 0 and self.brushPoint is not None:
                end = self.brushPoint
            else:
                end = (point.x, point.y)
            if engine.dist(end, self.samples[-1]) > 0.5:
                self.samples.append(end)
        try:
            self.commit()
        except Exception:
            print("Blobbington: the stroke could not be added. Please report this:")
            print(traceback.format_exc())
        self.clearStroke()
        self.showNibAt((point.x, point.y))

    # ---- commit ----

    def commit(self):
        """Fit the stroke and add its contours to the glyph as one undo step."""
        glyph = self.getGlyph()
        if glyph is None or not self.samples:
            return
        rx, ry = brushRadii(self.settings)
        contours, stats = engine.strokeOutlines(
            self.samples, rx, ry, self.settings["angle"], self.settings["fidelity"])
        if not contours:
            return
        with glyph.undo("Blobbington"):
            before = len(glyph.contours)
            pen = glyph.getPen()
            for segments in contours:
                engine.drawSegments(pen, segments)
            for contour in glyph.contours[before:]:
                markSmooth(contour)
            glyph.changed()
        if DEBUG:
            print("Blobbington:", stats)


installTool(BlobbingtonTool())
