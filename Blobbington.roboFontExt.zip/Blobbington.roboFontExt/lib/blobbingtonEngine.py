"""
Blobbington engine: turns a pen stroke into clean outline contours.

This module is pure geometry. It has no RoboFont dependencies, only
`booleanOperations` (bundled with RoboFont), so it can be tested outside
the app.

The pipeline, in order:

1. **Nib**: the brush is an oval with a size, an angle and a roundness.
   It is approximated by a convex polygon (`nibOffsets`).

2. **Sweep**: for every pair of consecutive samples along the stroke, the
   nib is swept in a straight line from one to the other. The swept area of
   a convex shape moving in a straight line is the convex hull of the shape
   at both ends (`sweepHull`). This is the ink model: the mark is exactly
   every position the nib passed through, like a pen on paper.

3. **Merge**: all swept pieces are unioned into outline polygons with
   `booleanOperations.union` (`unionPolygons`).

4. **Fit**: each outline polygon is converted into the fewest cubic bezier
   curves and lines that stay within a tolerance of the ink
   (`fitClosed`, based on Philip J. Schneider's algorithm from Graphics
   Gems, 1990). The tolerance comes from the Fidelity setting and is
   capped by the local width of the stroke, so thin hairlines are never
   distorted by a loose tolerance meant for thick parts.

The public entry points are `strokeOutlines` (the whole pipeline) and the
nib helpers `nibOffsets`, `nibAt` and `sweepHull` (used for the preview).

Fitted contours are returned as lists of segments. Each segment is a tuple:

    ("line",  p0, None, None, p3)
    ("curve", p0, c1,   c2,   p3)

where every point is an (x, y) tuple and each segment starts where the
previous one ends. `drawSegments` draws them with any fontTools-style pen.
"""

import math

import booleanOperations

try:
    import pyclipper
except ImportError:
    pyclipper = None


# ---------------------------------------------------------------------------
# Tuning constants
# ---------------------------------------------------------------------------

NIB_SAMPLES = 36        # nib polygon resolution, samples per sampling method

CENTERLINE_TOL = 0.25   # drop stroke samples that deviate less than this (font units);
                        # invisible at any zoom, and it keeps the merge fast

CLIPPER_SCALE = 1 << 17 # coordinates are scaled to integers for the clipper,
                        # the same scale booleanOperations uses
UNION_BATCH = 16        # swept pieces merged together before merging batches

FIT_TOL_MIN = 0.8       # maximum fitting error at Fidelity 1 (Accurate), font units
FIT_TOL_STEP = 0.4      # additional error allowed per Fidelity step towards Smooth
TOL_WIDTH_CAP = 0.4     # error never exceeds this share of the local half-width
TOL_FLOOR = 0.6         # smallest error allowed anywhere, font units

LINE_FRACTION = 0.35    # a run that stays within this share of the error of its
                        # chord becomes a straight line
CORNER_ANGLE = 50.0     # outline turns sharper than this (degrees) stay corners
CORNER_WINDOW = 3.0     # corner detection looks this many tolerances either side
CORNER_NIB_CAP = 0.25   # but never further than this share of the cap's radius, so
                        # the round end of a small nib is not read as a corner
TOL_NIB_CAP = 0.15      # fitting error never exceeds this share of the cap's radius
MIN_FIT_TOL = 0.1       # smallest fitting error, font units
SNAP_ANGLE = 20.0       # line to curve joins closer than this (degrees) are made
                        # tangent, so a straight flows into a curve cleanly

RESAMPLE_STEP = 4.0     # extra check points along long outline edges, so the
                        # fitter cannot bow a straight edge between its ends
TIP_SHARP = 1.0         # nib tips with a curvature radius below this (font units)
                        # leave crisp corners at the ends of a stroke
TIP_SNAP = 1.5          # how close an outline point must be to a nib tip
TIP_MERGE = 4.0         # corners this close to a nib tip corner are the same corner


# ---------------------------------------------------------------------------
# Small vector helpers
# ---------------------------------------------------------------------------

def v_sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def v_add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def v_mul(a, s):
    return (a[0] * s, a[1] * s)


def v_dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def v_len(a):
    return math.hypot(a[0], a[1])


def v_norm(a):
    """Unit vector in the direction of `a`, or (0, 0) for a zero vector."""
    m = math.hypot(a[0], a[1])
    if m == 0:
        return (0.0, 0.0)
    return (a[0] / m, a[1] / m)


def dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def segDistSq(p, a, b):
    """Squared distance from point `p` to the line segment from `a` to `b`."""
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    L = dx * dx + dy * dy
    if L == 0:
        return (p[0] - a[0]) ** 2 + (p[1] - a[1]) ** 2
    t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L
    t = max(0.0, min(1.0, t))
    qx = a[0] + t * dx
    qy = a[1] + t * dy
    return (p[0] - qx) ** 2 + (p[1] - qy) ** 2


# ---------------------------------------------------------------------------
# Polygon helpers
# ---------------------------------------------------------------------------

def polyArea(pts):
    """Signed area of a closed polygon. Positive means counter-clockwise."""
    a = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def cleanPoly(pts, eps=0.01):
    """Remove consecutive duplicate points, including a repeated start point."""
    out = []
    for p in pts:
        if not out or abs(p[0] - out[-1][0]) > eps or abs(p[1] - out[-1][1]) > eps:
            out.append(p)
    while len(out) > 1 and abs(out[0][0] - out[-1][0]) <= eps and abs(out[0][1] - out[-1][1]) <= eps:
        out.pop()
    return out


def resamplePoly(pts, step):
    """
    Add evenly spaced points along every edge of a closed polygon that is
    longer than `step`. The new points lie exactly on the edges, so the shape
    is unchanged; they only give the curve fitter something to measure its
    error against in the middle of long straight edges.
    """
    out = []
    n = len(pts)
    for i in range(n):
        a = pts[i]
        b = pts[(i + 1) % n]
        out.append(a)
        d = dist(a, b)
        if d > step:
            k = int(d / step)
            for j in range(1, k + 1):
                t = j / float(k + 1)
                out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
    return out


def nearestIndex(pts, q, radius):
    """Index of the point in `pts` closest to `q` within `radius`, or None."""
    best = None
    bd = radius * radius
    for i, p in enumerate(pts):
        d = (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2
        if d <= bd:
            bd = d
            best = i
    return best


def douglasPeucker(pts, tol):
    """
    Simplify an open polyline, keeping only points that deviate more than
    `tol` from the simplified line. Iterative, so long strokes cannot hit
    Python's recursion limit.
    """
    n = len(pts)
    if n < 3:
        return list(pts)
    keep = [False] * n
    keep[0] = True
    keep[-1] = True
    tol2 = tol * tol
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        worst = -1.0
        idx = -1
        for k in range(i + 1, j):
            d = segDistSq(pts[k], pts[i], pts[j])
            if d > worst:
                worst = d
                idx = k
        if worst > tol2:
            keep[idx] = True
            stack.append((i, idx))
            stack.append((idx, j))
    return [pts[k] for k in range(n) if keep[k]]


def constrainPoint(origin, pt):
    """Snap `pt` to the nearest 45 degree direction from `origin`, keeping its distance."""
    dx = pt[0] - origin[0]
    dy = pt[1] - origin[1]
    d = math.hypot(dx, dy)
    if d == 0:
        return pt
    ang = round(math.degrees(math.atan2(dy, dx)) / 45.0) * 45.0
    r = math.radians(ang)
    return (origin[0] + math.cos(r) * d, origin[1] + math.sin(r) * d)


# ---------------------------------------------------------------------------
# Nib
# ---------------------------------------------------------------------------

def ovalTransform(rx, ry, angleDeg):
    """
    The oval nib is the unit circle scaled by (rx, ry) and then rotated by
    `angleDeg`. Returns that transform as a function of (x, y).
    """
    a = math.radians(angleDeg)
    c = math.cos(a)
    s = math.sin(a)

    def M(px, py):
        sx = rx * px
        sy = ry * py
        return (sx * c - sy * s, sx * s + sy * c)
    return M


def ovalTransformT(rx, ry, angleDeg):
    """The transpose of `ovalTransform`, used to find the nib's support points."""
    a = math.radians(angleDeg)
    c = math.cos(a)
    s = math.sin(a)

    def MT(px, py):
        return (rx * (px * c + py * s), ry * (-px * s + py * c))
    return MT


def convexHull(points):
    """Convex hull of a point set, counter-clockwise (Andrew's monotone chain)."""
    pts = sorted(set(points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def nibOffsets(rx, ry, angleDeg):
    """
    The nib as a convex polygon centred on (0, 0), counter-clockwise.

    Two sampling methods are combined: sampling by outward direction places
    points densely around the tips of a flat nib, and sampling by angle
    around the oval covers its long flat sides. Together they describe
    everything from a round marker to a flat broad nib accurately.
    """
    M = ovalTransform(rx, ry, angleDeg)
    MT = ovalTransformT(rx, ry, angleDeg)
    pts = []
    for k in range(NIB_SAMPLES):
        a = 2.0 * math.pi * k / NIB_SAMPLES
        tx, ty = MT(math.cos(a), math.sin(a))
        m = math.hypot(tx, ty)
        if m > 0:
            pts.append(M(tx / m, ty / m))
        pts.append(M(math.cos(a), math.sin(a)))
    return convexHull(pts)


def nibAt(offs, p):
    """The nib polygon placed at point `p`."""
    return [(p[0] + ox, p[1] + oy) for ox, oy in offs]


def sweepHull(offs, a, b):
    """The area covered by the nib moving in a straight line from `a` to `b`."""
    if dist(a, b) < 1e-9:
        return nibAt(offs, a)
    return convexHull(nibAt(offs, a) + nibAt(offs, b))


def nibSupportOffset(rx, ry, angleDeg, direction):
    """
    Offset from the nib centre to the point furthest in `direction`. Sweeping
    the nib traces these points, so with `direction` perpendicular to travel
    they are exactly where the swept sides meet the nib at either end.
    """
    MT = ovalTransformT(rx, ry, angleDeg)
    tx, ty = MT(direction[0], direction[1])
    m = math.hypot(tx, ty)
    if m == 0:
        return (0.0, 0.0)
    return ovalTransform(rx, ry, angleDeg)(tx / m, ty / m)


def sideJunctions(rx, ry, angleDeg, center):
    """
    The points on a stroke's outline where each end cap meets a swept side.
    The curvature changes there, so the fit has to break at these points:
    otherwise one curve covers both the round end and the straight side and
    bows across the join. Tangents stay continuous, so they are not corners.
    """
    if len(center) < 2:
        return []
    out = []
    for a, b in ((center[1], center[0]), (center[-2], center[-1])):
        d = v_norm(v_sub(b, a))
        if d == (0.0, 0.0):
            continue
        normal = (-d[1], d[0])
        for sign in (1.0, -1.0):
            ox, oy = nibSupportOffset(rx, ry, angleDeg, v_mul(normal, sign))
            out.append((b[0] + ox, b[1] + oy))
    return out


def nibTipOffset(rx, ry, angleDeg):
    """Offset from the nib centre to one end of its long axis."""
    return ovalTransform(rx, ry, angleDeg)(1.0, 0.0)


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------

class _PolygonContour(object):
    """
    Minimal contour object for `booleanOperations`, which only needs
    `len()` and `drawPoints()`. Avoids building glyph objects just to merge.
    """

    def __init__(self, points):
        self.points = points

    def __len__(self):
        return len(self.points)

    def drawPoints(self, pointPen):
        pointPen.beginPath()
        for pt in self.points:
            pointPen.addPoint(pt, segmentType="line")
        pointPen.endPath()


class _PolygonCollector(object):
    """
    Point pen that collects `booleanOperations` output as polygons.
    Any curve segments are flattened, although line-only input normally
    produces line-only output.
    """

    def __init__(self):
        self.contours = []
        self._points = None

    def beginPath(self, identifier=None, **kwargs):
        self._points = []

    def addPoint(self, pt, segmentType=None, smooth=False, name=None, identifier=None, **kwargs):
        self._points.append(((pt[0], pt[1]), segmentType))

    def endPath(self):
        points = self._points or []
        self._points = None
        if not points:
            return
        # rotate so the list starts on an on-curve point
        start = 0
        for i, (_, t) in enumerate(points):
            if t is not None:
                start = i
                break
        points = points[start + 1:] + points[:start + 1]
        poly = []
        offcurves = []
        current = points[-1][0]
        for pt, t in points:
            if t is None:
                offcurves.append(pt)
                continue
            if t == "curve" and len(offcurves) == 2:
                c1, c2 = offcurves
                for k in range(1, 9):
                    s = k / 8.0
                    ms = 1.0 - s
                    poly.append((
                        ms ** 3 * current[0] + 3 * ms * ms * s * c1[0] + 3 * ms * s * s * c2[0] + s ** 3 * pt[0],
                        ms ** 3 * current[1] + 3 * ms * ms * s * c1[1] + 3 * ms * s * s * c2[1] + s ** 3 * pt[1],
                    ))
            else:
                poly.extend(offcurves)
                poly.append(pt)
            offcurves = []
            current = pt
        self.contours.append(poly)

    def addComponent(self, baseGlyphName, transformation, identifier=None, **kwargs):
        pass


def _clipperUnion(paths):
    """Union of integer-scaled paths with pyclipper, nonzero fill."""
    pc = pyclipper.Pyclipper()
    pc.AddPaths(paths, pyclipper.PT_SUBJECT, True)
    return pc.Execute(pyclipper.CT_UNION, pyclipper.PFT_NONZERO, pyclipper.PFT_NONZERO)


def _batchedUnion(polys):
    """
    Merge the swept pieces in small neighbourhoods first, then merge the
    results pairwise. Consecutive pieces overlap almost entirely, and
    handing the clipper hundreds of them at once is slow; batching gives
    an identical result much faster (about 25 times on long strokes).
    Neighbouring batches share a stroke sample, so they always touch.
    """
    scaled = pyclipper.scale_to_clipper(polys, CLIPPER_SCALE)
    groups = [_clipperUnion(scaled[i:i + UNION_BATCH]) for i in range(0, len(scaled), UNION_BATCH)]
    while len(groups) > 1:
        merged = []
        for i in range(0, len(groups), 2):
            pair = groups[i] + (groups[i + 1] if i + 1 < len(groups) else [])
            merged.append(_clipperUnion(pair))
        groups = merged
    return [[(p[0], p[1]) for p in path]
            for path in pyclipper.scale_from_clipper(groups[0], CLIPPER_SCALE)]


def unionPolygons(polys):
    """
    Merge overlapping polygons into outline polygons, holes included.
    Outer contours come out counter-clockwise and holes clockwise.

    The swept pieces are straight-edged polygons, so they go directly to
    pyclipper, the clipping engine `booleanOperations` itself uses. That
    skips its curve reconstruction step, which only matters for curved
    input. If pyclipper cannot be imported, `booleanOperations.union` is
    used instead, which gives the same result more slowly.
    """
    polys = [p for p in polys if len(p) >= 3]
    if not polys:
        return []
    if pyclipper is not None:
        raw = _batchedUnion(polys)
    else:
        collector = _PolygonCollector()
        booleanOperations.union([_PolygonContour(p) for p in polys], collector)
        raw = collector.contours
    result = []
    for c in raw:
        c = cleanPoly(c)
        if len(c) >= 3 and abs(polyArea(c)) >= 1.0:
            result.append(c)
    return result


# ---------------------------------------------------------------------------
# Local stroke width
# ---------------------------------------------------------------------------

def localHalfWidths(pts, center, reach):
    """
    Distance from each outline point to the stroke's centerline, capped at
    `reach`. This is the local half-width of the stroke, used so the fitting
    tolerance never exceeds a fraction of how thick the stroke actually is
    at that point. A spatial grid keeps it fast on long strokes.
    """
    if len(center) == 1:
        c0 = center[0]
        return [min(reach, dist(p, c0)) for p in pts]
    cell = max(reach, 1.0)
    grid = {}
    for i in range(len(center) - 1):
        a = center[i]
        b = center[i + 1]
        x0 = int(math.floor((min(a[0], b[0]) - reach) / cell))
        x1 = int(math.floor((max(a[0], b[0]) + reach) / cell))
        y0 = int(math.floor((min(a[1], b[1]) - reach) / cell))
        y1 = int(math.floor((max(a[1], b[1]) + reach) / cell))
        for gx in range(x0, x1 + 1):
            for gy in range(y0, y1 + 1):
                grid.setdefault((gx, gy), []).append(i)
    reach2 = reach * reach
    out = []
    for p in pts:
        key = (int(math.floor(p[0] / cell)), int(math.floor(p[1] / cell)))
        best = reach2
        for i in grid.get(key, ()):
            d = segDistSq(p, center[i], center[i + 1])
            if d < best:
                best = d
        out.append(math.sqrt(best))
    return out


# ---------------------------------------------------------------------------
# Curve fitting (after Schneider, "An Algorithm for Automatically Fitting
# Digitized Curves", Graphics Gems 1990)
# ---------------------------------------------------------------------------

def bezPoint(b, t):
    """Point on the cubic bezier `b` (four points) at parameter `t`."""
    mt = 1.0 - t
    a = mt * mt * mt
    c1 = 3.0 * mt * mt * t
    c2 = 3.0 * mt * t * t
    d = t * t * t
    return (a * b[0][0] + c1 * b[1][0] + c2 * b[2][0] + d * b[3][0],
            a * b[0][1] + c1 * b[1][1] + c2 * b[2][1] + d * b[3][1])


def walkIndex(pts, i, step, target):
    """Walk along an open point list from `i` until `target` distance is covered."""
    d = 0.0
    j = i
    n = len(pts)
    while True:
        k = j + step
        if k < 0 or k >= n:
            return j
        d += dist(pts[k], pts[j])
        j = k
        if d >= target:
            return j


def startTangent(pts, w):
    """Unit direction leaving the first point, measured over distance `w`."""
    j = walkIndex(pts, 0, 1, w)
    t = v_norm(v_sub(pts[j], pts[0]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[-1], pts[0]))
    return t


def endTangent(pts, w):
    """Unit direction pointing back into the run from its last point."""
    n = len(pts)
    j = walkIndex(pts, n - 1, -1, w)
    t = v_norm(v_sub(pts[j], pts[n - 1]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[0], pts[n - 1]))
    return t


def centerTangent(pts, i, w):
    """Unit tangent at an interior point, pointing backwards along the run."""
    a = walkIndex(pts, i, -1, w)
    b = walkIndex(pts, i, 1, w)
    t = v_norm(v_sub(pts[a], pts[b]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[i - 1], pts[i + 1]))
    return t


def chordParams(pts, first, last):
    """Parameter values for the points by cumulative chord length, 0 to 1."""
    u = [0.0]
    for i in range(first + 1, last + 1):
        u.append(u[-1] + dist(pts[i], pts[i - 1]))
    total = u[-1]
    if total == 0:
        n = len(u)
        return [k / float(n - 1) for k in range(n)]
    return [x / total for x in u]


def generateBezier(pts, first, last, u, t1, t2):
    """
    Least-squares cubic through pts[first..last] with fixed end points and
    end tangent directions `t1` (forwards) and `t2` (backwards). Only the
    handle lengths are solved for.
    """
    p0 = pts[first]
    p3 = pts[last]
    c00 = 0.0
    c01 = 0.0
    c11 = 0.0
    x0 = 0.0
    x1 = 0.0
    for idx in range(len(u)):
        t = u[idx]
        mt = 1.0 - t
        b0 = mt * mt * mt
        b1 = 3.0 * mt * mt * t
        b2 = 3.0 * mt * t * t
        b3 = t * t * t
        a1 = v_mul(t1, b1)
        a2 = v_mul(t2, b2)
        c00 += v_dot(a1, a1)
        c01 += v_dot(a1, a2)
        c11 += v_dot(a2, a2)
        p = pts[first + idx]
        tmp = (p[0] - (p0[0] * (b0 + b1) + p3[0] * (b2 + b3)),
               p[1] - (p0[1] * (b0 + b1) + p3[1] * (b2 + b3)))
        x0 += v_dot(a1, tmp)
        x1 += v_dot(a2, tmp)
    det = c00 * c11 - c01 * c01
    seg = dist(p0, p3)
    alphaL = 0.0
    alphaR = 0.0
    if abs(det) > 1e-12:
        alphaL = (x0 * c11 - x1 * c01) / det
        alphaR = (c00 * x1 - c01 * x0) / det
    eps = 1e-6 * seg
    if alphaL < eps or alphaR < eps or alphaL > seg * 3.0 or alphaR > seg * 3.0:
        # degenerate solution: fall back to handles one third of the chord
        d = seg / 3.0
        return (p0, v_add(p0, v_mul(t1, d)), v_add(p3, v_mul(t2, d)), p3)
    return (p0, v_add(p0, v_mul(t1, alphaL)), v_add(p3, v_mul(t2, alphaR)), p3)


def maxError(pts, tols, first, last, bez, u):
    """
    Worst fitting error, measured relative to each point's own tolerance,
    and the index where it occurs. A result below 1.0 means every point is
    within its tolerance.
    """
    worst = 0.0
    split = (first + last) // 2
    for i in range(first + 1, last):
        p = bezPoint(bez, u[i - first])
        d = ((p[0] - pts[i][0]) ** 2 + (p[1] - pts[i][1]) ** 2) / (tols[i] * tols[i])
        if d >= worst:
            worst = d
            split = i
    return worst, split


def reparameterize(pts, first, last, u, bez):
    """Improve the parameter values with one Newton-Raphson step each."""
    q1 = [v_mul(v_sub(bez[i + 1], bez[i]), 3.0) for i in range(3)]
    q2 = [v_mul(v_sub(q1[i + 1], q1[i]), 2.0) for i in range(2)]
    out = []
    for idx in range(len(u)):
        t = u[idx]
        p = pts[first + idx]
        qt = bezPoint(bez, t)
        mt = 1.0 - t
        q1t = (mt * mt * q1[0][0] + 2.0 * mt * t * q1[1][0] + t * t * q1[2][0],
               mt * mt * q1[0][1] + 2.0 * mt * t * q1[1][1] + t * t * q1[2][1])
        q2t = (mt * q2[0][0] + t * q2[1][0], mt * q2[0][1] + t * q2[1][1])
        diff = v_sub(qt, p)
        num = v_dot(diff, q1t)
        den = v_dot(q1t, q1t) + v_dot(diff, q2t)
        if abs(den) < 1e-12:
            out.append(t)
        else:
            out.append(max(0.0, min(1.0, t - num / den)))
    return out


def fitsLine(pts, tols, first, last):
    """True if every point in the run stays close enough to its chord to be a line."""
    a = pts[first]
    b = pts[last]
    for i in range(first + 1, last):
        lt = LINE_FRACTION * tols[i]
        if segDistSq(pts[i], a, b) > lt * lt:
            return False
    return True


def fitRun(pts, tols, t1=None, t2=None):
    """
    Fit an open run of points with the fewest lines and cubic curves that
    keep every point within its tolerance. Spans that fail are split at the
    worst point and fitted again. Uses an explicit stack instead of
    recursion so long runs are safe.
    """
    n = len(pts)
    if n < 2:
        return []
    w = max(1.5, 2.0 * max(tols))
    cosSnap = math.cos(math.radians(SNAP_ANGLE))
    if t1 is None:
        t1 = startTangent(pts, w)
    if t2 is None:
        t2 = endTangent(pts, w)
    out = []
    stack = [(0, n - 1, t1, t2)]
    while stack:
        first, last, ta, tb = stack.pop()
        if last <= first:
            continue
        p0 = pts[first]
        p3 = pts[last]

        if dist(p0, p3) < 1e-9:
            # a span that returns to its own start (a closed loop) cannot be
            # one curve: split it at the point furthest away
            if last - first < 2:
                continue
            far = first + 1
            best = -1.0
            for i in range(first + 1, last):
                d = dist(pts[i], p0)
                if d > best:
                    best = d
                    far = i
            tc = centerTangent(pts, far, w)
            stack.append((far, last, v_mul(tc, -1.0), tb))
            stack.append((first, far, ta, tc))
            continue

        if last - first == 1:
            chord = v_norm(v_sub(p3, p0))
            if v_dot(ta, chord) >= cosSnap and v_dot(tb, v_mul(chord, -1.0)) >= cosSnap:
                out.append(("line", p0, None, None, p3))
            else:
                d = dist(p0, p3) / 3.0
                out.append(("curve", p0, v_add(p0, v_mul(ta, d)), v_add(p3, v_mul(tb, d)), p3))
            continue

        if fitsLine(pts, tols, first, last):
            out.append(("line", p0, None, None, p3))
            continue

        u = chordParams(pts, first, last)
        bez = generateBezier(pts, first, last, u, ta, tb)
        worst, split = maxError(pts, tols, first, last, bez, u)
        if worst < 1.0:
            out.append(("curve",) + tuple(bez))
            continue
        if worst < 4.0:
            done = False
            for _ in range(4):
                u = reparameterize(pts, first, last, u, bez)
                bez = generateBezier(pts, first, last, u, ta, tb)
                worst, split = maxError(pts, tols, first, last, bez, u)
                if worst < 1.0:
                    done = True
                    break
            if done:
                out.append(("curve",) + tuple(bez))
                continue
        if split <= first or split >= last:
            split = (first + last) // 2
        tc = centerTangent(pts, split, w)
        # push the right half first so the left half is fitted first
        # and segments come out in order
        stack.append((split, last, v_mul(tc, -1.0), tb))
        stack.append((first, split, ta, tc))
    return out


def closedWalk(pts, i, step, target):
    """Like `walkIndex`, but wraps around a closed polygon."""
    n = len(pts)
    d = 0.0
    j = i
    for _ in range(n - 1):
        k = (j + step) % n
        d += dist(pts[k], pts[j])
        j = k
        if d >= target:
            break
    return j


def closedTangent(pts, i, w):
    """Unit tangent at point `i` of a closed polygon, pointing backwards."""
    n = len(pts)
    a = closedWalk(pts, i, -1, w)
    b = closedWalk(pts, i, 1, w)
    t = v_norm(v_sub(pts[a], pts[b]))
    if t == (0.0, 0.0):
        t = v_norm(v_sub(pts[(i - 1) % n], pts[(i + 1) % n]))
    return t


def findOutlineCorners(pts, w, total):
    """
    Indices of genuine corners on a closed outline. The turn at each point
    is measured across a window of `w` either side, so small wobbles do
    not count as corners while real ones do. Candidates closer together
    than `w` are merged, keeping the sharpest.
    """
    n = len(pts)
    if n < 4:
        return []
    turns = []
    for i in range(n):
        a = closedWalk(pts, i, -1, w)
        b = closedWalk(pts, i, 1, w)
        v1 = v_norm(v_sub(pts[i], pts[a]))
        v2 = v_norm(v_sub(pts[b], pts[i]))
        if v1 == (0.0, 0.0) or v2 == (0.0, 0.0):
            turns.append(0.0)
            continue
        cosv = max(-1.0, min(1.0, v_dot(v1, v2)))
        turns.append(math.degrees(math.acos(cosv)))
    cum = [0.0]
    for i in range(1, n):
        cum.append(cum[-1] + dist(pts[i], pts[i - 1]))
    cands = [i for i in range(n) if turns[i] >= CORNER_ANGLE]
    cands.sort(key=lambda i: -turns[i])
    chosen = []
    for i in cands:
        ok = True
        for k in chosen:
            d = abs(cum[i] - cum[k])
            d = min(d, total - d)
            if d < w:
                ok = False
                break
        if ok:
            chosen.append(i)
    chosen.sort()
    return chosen


def fitClosed(pts, tols, globalTol, tipPoints, cornerWindowMax=None, splitPoints=None):
    """
    Fit a closed outline polygon. It is split into runs at its corners
    (detected corners plus the nib tip corners in `tipPoints`) and each run
    is fitted on its own, so corners stay sharp and everything between them
    stays smooth. Returns (segments, cornerPoints).
    """
    n = len(pts)
    if n < 3:
        return [], set()
    cum = [0.0]
    for i in range(1, n):
        cum.append(cum[-1] + dist(pts[i], pts[i - 1]))
    total = cum[-1] + dist(pts[-1], pts[0])
    if total <= 0:
        return [], set()
    w = min(max(1.5, CORNER_WINDOW * globalTol), total / 8.0)
    if cornerWindowMax is not None:
        w = max(min(w, cornerWindowMax), 1e-6)
    corners = findOutlineCorners(pts, w, total)

    if tipPoints:
        tipIdx = []
        for q in tipPoints:
            k = nearestIndex(pts, q, TIP_SNAP)
            if k is not None and k not in tipIdx:
                tipIdx.append(k)
        merged = list(tipIdx)
        for c in corners:
            near = False
            for k in tipIdx:
                d = abs(cum[c] - cum[k])
                d = min(d, total - d)
                if d < TIP_MERGE:
                    near = True
                    break
            if not near:
                merged.append(c)
        corners = sorted(set(merged))

    cornerPts = set(pts[c] for c in corners)

    # curvature junctions: break the fit, but stay smooth
    if splitPoints:
        for q in splitPoints:
            k = nearestIndex(pts, q, TIP_SNAP)
            if k is None or k in corners:
                continue
            tooClose = False
            for c in corners:
                d = abs(cum[k] - cum[c])
                if min(d, total - d) < TIP_MERGE:
                    tooClose = True
                    break
            if not tooClose:
                corners.append(k)
        corners = sorted(set(corners))

    if not corners:
        tw = min(max(1.0, 2.0 * globalTol), total / 8.0)
        tc = closedTangent(pts, 0, tw)
        run = list(pts) + [pts[0]]
        runTols = list(tols) + [tols[0]]
        return fitRun(run, runTols, v_mul(tc, -1.0), tc), cornerPts

    segs = []
    count = len(corners)
    for j in range(count):
        c = corners[j]
        nc = corners[(j + 1) % count]
        if nc > c:
            run = pts[c:nc + 1]
            runTols = tols[c:nc + 1]
        else:
            run = pts[c:] + pts[:nc + 1]
            runTols = tols[c:] + tols[:nc + 1]
        segs.extend(fitRun(run, runTols))
    return segs, cornerPts


def curveIsStraight(s, eps=0.25):
    """True if a curve segment's handles lie on its chord, so it is really a line."""
    e2 = eps * eps
    return segDistSq(s[2], s[1], s[4]) <= e2 and segDistSq(s[3], s[1], s[4]) <= e2


def tidySegments(segs, cornerPts):
    """
    Final cleanup of a fitted contour: straight curves become lines,
    consecutive collinear lines merge, and wherever a line meets a curve
    at a join that is not a corner, the curve's handle is aligned with the
    line so the join is smooth.
    """
    out = []
    cos3 = math.cos(math.radians(3.0))
    for s in segs:
        if s[0] == "curve" and curveIsStraight(s):
            s = ("line", s[1], None, None, s[4])
        if out and s[0] == "line" and out[-1][0] == "line":
            a = v_norm(v_sub(out[-1][4], out[-1][1]))
            b = v_norm(v_sub(s[4], s[1]))
            if v_dot(a, b) >= cos3:
                out[-1] = ("line", out[-1][1], None, None, s[4])
                continue
        out.append(s)
    n = len(out)
    cosSnap = math.cos(math.radians(SNAP_ANGLE))
    for i in range(n):
        a = out[i]
        j = (i + 1) % n
        b = out[j]
        if b[1] in cornerPts:
            continue
        if a[0] == "line" and b[0] == "curve":
            L = v_norm(v_sub(a[4], a[1]))
            h = v_sub(b[2], b[1])
            hl = v_len(h)
            if hl > 0 and v_dot(L, v_norm(h)) >= cosSnap:
                out[j] = ("curve", b[1], v_add(b[1], v_mul(L, hl)), b[3], b[4])
        elif a[0] == "curve" and b[0] == "line":
            L = v_norm(v_sub(b[4], b[1]))
            back = v_mul(L, -1.0)
            h = v_sub(a[3], a[4])
            hl = v_len(h)
            if hl > 0 and v_dot(back, v_norm(h)) >= cosSnap:
                out[i] = ("curve", a[1], a[2], v_add(a[4], v_mul(back, hl)), a[4])
    return out


def drawSegments(pen, segs):
    """Draw one fitted closed contour with a fontTools-style segment pen."""
    start = segs[0][1]
    pen.moveTo(start)
    last = len(segs) - 1
    for idx in range(len(segs)):
        s = segs[idx]
        if s[0] == "line":
            if idx == last and dist(s[4], start) < 1e-9:
                continue
            pen.lineTo(s[4])
        else:
            pen.curveTo(s[2], s[3], s[4])
    pen.closePath()


# ---------------------------------------------------------------------------
# Whole pipeline
# ---------------------------------------------------------------------------

def fitTolerance(fidelity):
    """Maximum fitting error for a Fidelity setting from 1 (Accurate) to 20 (Smooth)."""
    return FIT_TOL_MIN + (int(fidelity) - 1) * FIT_TOL_STEP


def strokeOutlines(samples, rx, ry, angleDeg, fidelity):
    """
    Turn a stroke into fitted outline contours.

    `samples` is the list of (x, y) points the nib travelled through, in
    order. A single sample makes one dab. `rx` and `ry` are the nib's radii
    and `angleDeg` its rotation. `fidelity` runs from 1 (Accurate) to 20
    (Smooth).

    Returns (contours, stats), where `contours` is a list of segment lists
    ready for `drawSegments`, and `stats` a dict of counts for debugging.
    """
    if not samples:
        return [], {}
    offs = nibOffsets(rx, ry, angleDeg)
    center = douglasPeucker(samples, CENTERLINE_TOL)
    if len(center) < 2:
        polys = [nibAt(offs, center[0])]
    else:
        polys = [sweepHull(offs, center[i], center[i + 1]) for i in range(len(center) - 1)]

    outline = unionPolygons(polys)

    # The nib's tips curve with radius ry * ry / rx. Everything about
    # fitting the ends of a stroke has to be measured against that radius,
    # not against absolute font units: on a small nib a tolerance or a
    # corner detection window meant for a large one is wider than the cap
    # itself, which reads the round end as a corner and distorts it.
    capRadius = (ry * ry / rx) if rx > 0 else ry
    sharpTips = capRadius < TIP_SHARP

    # a nearly flat nib leaves crisp points where its tips sit at either end
    tipPoints = []
    if sharpTips:
        tx, ty = nibTipOffset(rx, ry, angleDeg)
        for c in (center[0], center[-1]):
            tipPoints.append((c[0] + tx, c[1] + ty))
            tipPoints.append((c[0] - tx, c[1] - ty))

    junctions = sideJunctions(rx, ry, angleDeg, center)

    globalTol = fitTolerance(fidelity)
    cornerWindowMax = None
    if not sharpTips:
        # a round or oval nib: keep the caps smooth and accurate at any size
        globalTol = max(MIN_FIT_TOL, min(globalTol, TOL_NIB_CAP * capRadius))
        cornerWindowMax = CORNER_NIB_CAP * capRadius
    reach = globalTol / TOL_WIDTH_CAP

    contours = []
    outlinePoints = 0
    for poly in outline:
        poly = resamplePoly(poly, RESAMPLE_STEP)
        outlinePoints += len(poly)
        halfWidths = localHalfWidths(poly, center, reach)
        tols = [min(globalTol, max(TOL_FLOOR, TOL_WIDTH_CAP * h)) for h in halfWidths]
        segs, cornerPts = fitClosed(poly, tols, globalTol, tipPoints,
                                    cornerWindowMax, junctions)
        segs = tidySegments(segs, cornerPts)
        if len(segs) >= 2:
            contours.append(segs)

    stats = dict(
        samples=len(samples),
        centerline=len(center),
        outlinePoints=outlinePoints,
        segments=sum(len(s) for s in contours),
        lines=sum(1 for s in contours for seg in s if seg[0] == "line"),
        tolerance=globalTol,
    )
    return contours, stats
